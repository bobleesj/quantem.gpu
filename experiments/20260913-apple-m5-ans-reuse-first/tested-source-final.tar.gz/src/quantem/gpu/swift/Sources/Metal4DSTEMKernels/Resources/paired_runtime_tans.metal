#include <metal_stdlib>
using namespace metal;

constant uint PRT_STATES = 1024u;
constant uint PRT_SYMBOLS = 1089u;
constant uint PRT_ESCAPE = 1088u;
constant uint prt_sparse_slack_requested [[function_constant(4)]];
constant uint prt_sparse_slack = is_function_constant_defined(
    prt_sparse_slack_requested) ? prt_sparse_slack_requested : 0u;
constant bool prt_scratchless_encode_requested [[function_constant(7)]];
constant bool prt_scratchless_encode = is_function_constant_defined(
    prt_scratchless_encode_requested) ? prt_scratchless_encode_requested : false;
constant bool prt_compact_offsets_requested [[function_constant(20)]];
constant bool prt_compact_offsets = is_function_constant_defined(
    prt_compact_offsets_requested) ? prt_compact_offsets_requested : false;
constant uint PRT_INTERVAL = 512u;

inline uint prt_source_offset(
    device const uint *offsets, uint stream, uint stream_count) {
    if (!prt_compact_offsets) return offsets[stream];
    uint base_count = (stream_count >> 5u) + 1u;
    device const uchar *bytes = reinterpret_cast<device const uchar *>(offsets);
    device const ushort *starts = reinterpret_cast<device const ushort *>(
        bytes + ulong(base_count) * sizeof(uint));
    return offsets[stream >> 5u] + uint(starts[stream]);
}

inline uint prt_raw(
    device const uchar *raw, ulong index, uint item_bytes) {
    return item_bytes == 1u
        ? uint(raw[index])
        : uint(reinterpret_cast<device const ushort *>(raw)[index]);
}

inline void prt_scratch_byte(
    device uchar *scratch, device const uint *direct_offsets,
    uint streams, uint stream, uint byte, uchar value, bool direct_write) {
    if (prt_scratchless_encode) {
        if (direct_write) {
            uint first = direct_offsets[stream];
            uint end = direct_offsets[stream + 1u];
            if (end >= first && byte < end - first)
                scratch[first + byte] = value;
        }
    } else {
        scratch[ulong(byte) * streams + stream] = value;
    }
}

inline void prt_append_bits(
    device uchar *scratch, uint streams, uint stream,
    thread ulong &buffer, thread uint &available, thread uint &emitted,
    thread bool &overflow, uint scratch_stride,
    device const uint *direct_offsets, bool direct_write,
    uint value, uint count) {
    if (count == 0u || overflow) return;
    buffer |= ulong(value) << available;
    available += count;
    while (available >= 8u) {
        if (2u + emitted >= scratch_stride) {
            overflow = true;
            return;
        }
        prt_scratch_byte(
            scratch, direct_offsets, streams, stream, 2u + emitted, uchar(buffer), direct_write);
        ++emitted;
        buffer >>= 8u;
        available -= 8u;
    }
}

inline uint prt_model(uint clipped_sum, uint count) {
    float mean = float(clipped_sum) / float(count);
    float scaled = (log(max(mean, 0.002f)) - log(0.002f))
        * float(31.0 / log(16000.0));
    return uint(clamp(int(rint(scaled)), 0, 31));
}

inline bool prt_entropy_mode(uint mode) {
    return mode >= 64u && mode < 96u;
}

inline uint prt_entropy_model(uint mode) {
    return mode - 64u;
}

kernel void paired_runtime_tans_encode(
    device const uchar *raw [[buffer(0)]],
    device const uint *frequency_starts [[buffer(1)]],
    device const ushort *encoding [[buffer(2)]],
    device uchar *scratch [[buffer(3)]],
    device uint *sizes [[buffer(4)]],
    device uchar *modes [[buffer(5)]],
    device atomic_uint *failure [[buffer(6)]],
    constant uint *p [[buffer(7)]],
    device const uint *direct_offsets [[buffer(8)]],
    uint stream [[thread_position_in_grid]]) {
    uint scans = p[0], pixels = p[1], streams = p[2], item_bytes = p[3];
    uint scratch_stride = p[4];
    bool direct_write = prt_scratchless_encode && p[5] != 0u;
    if (stream >= streams) return;
    uint pixel = stream % pixels;
    uint first = (stream / pixels) * PRT_INTERVAL;
    uint count = min(PRT_INTERVAL, scans - first);
    if (count == 0u || scratch_stride < 2u * count || (item_bytes != 1u && item_bytes != 2u)) {
        atomic_store_explicit(failure, 1u, memory_order_relaxed);
        return;
    }

    uint minimum = 65535u, maximum = 0u, nonzero = 0u, clipped_sum = 0u;
    uint first_event = 0u, second_event = 0u;
    for (uint scan = 0u; scan < count; ++scan) {
        uint value = prt_raw(raw, ulong(first + scan) * pixels + pixel, item_bytes);
        minimum = min(minimum, value);
        maximum = max(maximum, value);
        if (value != 0u && nonzero < 2u) {
            uint event = (scan << 7u) | (value - 1u);
            if (nonzero == 0u) first_event = event;
            else second_event = event;
        }
        nonzero += value != 0u;
        clipped_sum += min(value, 32u);
    }
    if (minimum == maximum) {
        if (maximum == 0u) {
            modes[stream] = 253u;
            sizes[stream] = 0u;
        } else {
            modes[stream] = 255u;
            sizes[stream] = 2u;
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 0u, uchar(maximum), direct_write);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 1u, uchar(maximum >> 8u), direct_write);
        }
        return;
    }
    if (maximum <= 128u && nonzero <= 2u) {
        if (nonzero > 0u) {
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 0u, uchar(first_event), direct_write);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 1u, uchar(first_event >> 8u), direct_write);
        }
        if (nonzero > 1u) {
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 2u, uchar(second_event), direct_write);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 3u, uchar(second_event >> 8u), direct_write);
        }
        modes[stream] = 252u;
        sizes[stream] = 2u * nonzero;
        return;
    }

    uint model = prt_model(clipped_sum, count);
    uint state = 0u;
    uint total_bits = 0u, emitted = 0u, available = 0u;
    bool entropy_overflow = false;
    ulong bit_buffer = 0u;
    uint pairs = (count + 1u) / 2u;
    for (uint reverse_pair = pairs; reverse_pair > 0u; --reverse_pair) {
        uint index = (reverse_pair - 1u) * 2u;
        uint a = prt_raw(raw, ulong(first + index) * pixels + pixel, item_bytes);
        uint b = index + 1u < count
            ? prt_raw(raw, ulong(first + index + 1u) * pixels + pixel, item_bytes)
            : 0u;
        uint symbol = a < 32u && b < 32u ? a * 33u + b : PRT_ESCAPE;
        uint frequency_start = frequency_starts[model * PRT_SYMBOLS + symbol];
        uint frequency = frequency_start >> 16u;
        if (symbol == PRT_ESCAPE || frequency == 0u) {
            symbol = PRT_ESCAPE;
            frequency_start = frequency_starts[model * PRT_SYMBOLS + symbol];
            frequency = frequency_start >> 16u;
            if (a < 64u && b < 64u) {
                prt_append_bits(
                    scratch, streams, stream, bit_buffer, available, emitted,
                    entropy_overflow, scratch_stride, direct_offsets, direct_write,
                    a | (b << 6u), 13u);
                total_bits += 13u;
            } else {
                prt_append_bits(
                    scratch, streams, stream, bit_buffer, available, emitted,
                    entropy_overflow, scratch_stride, direct_offsets, direct_write, b, 16u);
                prt_append_bits(
                    scratch, streams, stream, bit_buffer, available, emitted,
                    entropy_overflow, scratch_stride, direct_offsets, direct_write, a, 16u);
                prt_append_bits(
                    scratch, streams, stream, bit_buffer, available, emitted,
                    entropy_overflow, scratch_stride, direct_offsets, direct_write, 4096u, 13u);
                total_bits += 45u;
            }
        }
        uint start = frequency_start & 65535u;
        uint y = PRT_STATES + state;
        uint bits = 10u - (31u - clz(frequency));
        if (y < (frequency << bits)) --bits;
        uint rank = (y >> bits) - frequency;
        uint low = bits == 0u ? 0u : y & ((1u << bits) - 1u);
        prt_append_bits(
            scratch, streams, stream, bit_buffer, available, emitted,
            entropy_overflow, scratch_stride, direct_offsets, direct_write, low, bits);
        total_bits += bits;
        state = uint(encoding[model * PRT_STATES + start + rank]);
        if (entropy_overflow) break;
    }
    if (!entropy_overflow && available != 0u) {
        if (2u + emitted >= scratch_stride) {
            entropy_overflow = true;
        } else {
            prt_scratch_byte(
                scratch, direct_offsets, streams, stream, 2u + emitted, uchar(bit_buffer), direct_write);
            ++emitted;
        }
    }
    bool use_entropy = !entropy_overflow
        && emitted + 2u < 2u * count && total_bits < 16384u;
    uint size = use_entropy ? emitted + 2u : 2u * count;
    bool byte_optimal_sparse = 2u * nonzero <= size + 1u;
    bool speed_sparse = prt_sparse_slack != 0u && nonzero <= 64u
        && 2u * nonzero <= size + 1u + prt_sparse_slack;
    if (maximum <= 128u && (byte_optimal_sparse || speed_sparse)) {
        emitted = 0u;
        for (uint scan = 0u; scan < count; ++scan) {
            uint value = prt_raw(raw, ulong(first + scan) * pixels + pixel, item_bytes);
            if (value == 0u) continue;
            uint event = (scan << 7u) | (value - 1u);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, emitted++, uchar(event), direct_write);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, emitted++, uchar(event >> 8u), direct_write);
        }
        modes[stream] = 252u;
        sizes[stream] = emitted;
        return;
    }
    if (!use_entropy) {
        for (uint scan = 0u; scan < count; ++scan) {
            uint value = prt_raw(raw, ulong(first + scan) * pixels + pixel, item_bytes);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 2u * scan, uchar(value), direct_write);
            prt_scratch_byte(scratch, direct_offsets, streams, stream, 2u * scan + 1u, uchar(value >> 8u), direct_write);
        }
        modes[stream] = 254u;
        sizes[stream] = 2u * count;
        return;
    }
    uint header = (state << 6u) | (total_bits & 7u);
    prt_scratch_byte(scratch, direct_offsets, streams, stream, 0u, uchar(header), direct_write);
    prt_scratch_byte(scratch, direct_offsets, streams, stream, 1u, uchar(header >> 8u), direct_write);
    modes[stream] = uchar(64u + model);
    sizes[stream] = size;
}

kernel void paired_runtime_tans_compact(
    device const uchar *scratch [[buffer(0)]],
    device const uint *sizes [[buffer(1)]],
    device const uint *offsets [[buffer(2)]],
    device uchar *payload [[buffer(3)]],
    device atomic_uint *failure [[buffer(4)]],
    constant uint *p [[buffer(5)]],
    uint stream [[thread_position_in_grid]]) {
    uint streams = p[0], scratch_stride = p[1], payload_bytes = p[2];
    if (stream >= streams) return;
    uint first = offsets[stream], end = offsets[stream + 1u];
    if (end < first || end - first != sizes[stream] || end > payload_bytes
        || sizes[stream] > scratch_stride) {
        atomic_store_explicit(failure, 2u, memory_order_relaxed);
        return;
    }
    for (uint byte = 0u; byte < sizes[stream]; ++byte)
        payload[first + byte] = scratch[ulong(byte) * streams + stream];
}

struct PRTBitReader {
    device const uchar *payload;
    uint first;
    uint remaining;
    bool valid;

    PRTBitReader(device const uchar *bytes, uint body_first, uint meaningful)
        : payload(bytes), first(body_first), remaining(meaningful), valid(true) {}

    uint pop(uint count) {
        if (count > remaining) {
            valid = false;
            return 0u;
        }
        remaining -= count;
        uint value = 0u;
        for (uint bit = 0u; bit < count; ++bit) {
            uint position = remaining + bit;
            uint next = (uint(payload[first + position / 8u]) >> (position & 7u)) & 1u;
            value |= next << bit;
        }
        return value;
    }
};

kernel void paired_runtime_tans_decode(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device ushort *output [[buffer(4)]],
    device atomic_uint *failure [[buffer(5)]],
    constant uint *p [[buffer(6)]],
    uint stream [[thread_position_in_grid]]) {
    uint scans = p[0], pixels = p[1], streams = p[2], item_bytes = p[3];
    uint payload_bytes = p[4];
    if (stream >= streams) return;
    uint pixel = stream % pixels;
    uint first_scan = (stream / pixels) * PRT_INTERVAL;
    uint count = min(PRT_INTERVAL, scans - first_scan);
    uint first = prt_source_offset(offsets, stream, streams);
    uint end = prt_source_offset(offsets, stream + 1u, streams);
    if (count == 0u || end < first || end > payload_bytes
        || (item_bytes != 1u && item_bytes != 2u)) {
        atomic_store_explicit(failure, 3u, memory_order_relaxed);
        return;
    }
    uint mode = uint(modes[stream]);
    if (mode == 253u) {
        if (first != end) atomic_store_explicit(failure, 4u, memory_order_relaxed);
        for (uint scan = 0u; scan < count; ++scan)
            output[ulong(first_scan + scan) * pixels + pixel] = 0u;
        return;
    }
    if (mode == 255u) {
        if (end - first != 2u) {
            atomic_store_explicit(failure, 5u, memory_order_relaxed);
            return;
        }
        uint value = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
        if (item_bytes == 1u && value > 255u) {
            atomic_store_explicit(failure, 6u, memory_order_relaxed);
            return;
        }
        for (uint scan = 0u; scan < count; ++scan)
            output[ulong(first_scan + scan) * pixels + pixel] = ushort(value);
        return;
    }
    if (mode == 254u) {
        if (end - first != 2u * count) {
            atomic_store_explicit(failure, 7u, memory_order_relaxed);
            return;
        }
        for (uint scan = 0u; scan < count; ++scan) {
            uint value = uint(payload[first + 2u * scan])
                | (uint(payload[first + 2u * scan + 1u]) << 8u);
            if (item_bytes == 1u && value > 255u) {
                atomic_store_explicit(failure, 8u, memory_order_relaxed);
                return;
            }
            output[ulong(first_scan + scan) * pixels + pixel] = ushort(value);
        }
        return;
    }
    if (mode == 252u) {
        if (((end - first) & 1u) != 0u) {
            atomic_store_explicit(failure, 9u, memory_order_relaxed);
            return;
        }
        uint cursor = first, previous = 0u;
        bool has_previous = false;
        for (uint scan = 0u; scan < count; ++scan)
            output[ulong(first_scan + scan) * pixels + pixel] = 0u;
        while (cursor < end) {
            uint event = uint(payload[cursor]) | (uint(payload[cursor + 1u]) << 8u);
            cursor += 2u;
            uint scan = event >> 7u, value = (event & 127u) + 1u;
            if (scan >= count || (has_previous && scan <= previous)) {
                atomic_store_explicit(failure, 10u, memory_order_relaxed);
                return;
            }
            output[ulong(first_scan + scan) * pixels + pixel] = ushort(value);
            previous = scan;
            has_previous = true;
        }
        return;
    }
    if (!prt_entropy_mode(mode) || end - first < 2u) {
        atomic_store_explicit(failure, 11u, memory_order_relaxed);
        return;
    }
    uint header = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
    uint tail = header & 7u, state = header >> 6u;
    uint body_first = first + 2u, body_bytes = end - body_first;
    if (((header >> 3u) & 7u) != 0u || state >= PRT_STATES
        || (tail != 0u && body_bytes == 0u)) {
        atomic_store_explicit(failure, 12u, memory_order_relaxed);
        return;
    }
    uint padding = tail == 0u ? 0u : 8u - tail;
    uint meaningful = body_bytes * 8u - padding;
    if (tail != 0u && (uint(payload[end - 1u]) >> tail) != 0u) {
        atomic_store_explicit(failure, 13u, memory_order_relaxed);
        return;
    }
    PRTBitReader reader(payload, body_first, meaningful);
    uint model = prt_entropy_model(mode);
    for (uint index = 0u; index < count; index += 2u) {
        uint code = decoding[model * PRT_STATES + state];
        uint pair = code & 4095u, bits = (code >> 12u) & 15u;
        state = (code >> 16u) + reader.pop(bits);
        uint a, b;
        if (pair == 4095u) {
            uint word = reader.pop(13u);
            if (word < 4096u) {
                a = word & 63u;
                b = word >> 6u;
            } else if (word == 4096u) {
                a = reader.pop(16u);
                b = reader.pop(16u);
            } else {
                reader.valid = false;
                a = b = 0u;
            }
        } else {
            a = pair & 63u;
            b = pair >> 6u;
        }
        if (!reader.valid || state >= PRT_STATES || (item_bytes == 1u && (a > 255u || b > 255u))) {
            atomic_store_explicit(failure, 14u, memory_order_relaxed);
            return;
        }
        output[ulong(first_scan + index) * pixels + pixel] = ushort(a);
        if (index + 1u < count)
            output[ulong(first_scan + index + 1u) * pixels + pixel] = ushort(b);
        else if (b != 0u) {
            atomic_store_explicit(failure, 15u, memory_order_relaxed);
            return;
        }
    }
    if (reader.remaining != 0u || state != 0u)
        atomic_store_explicit(failure, 16u, memory_order_relaxed);
}

// Reverse stack reader used by the interactive kernels. The encoder appends
// fields least-significant bit first while walking pairs backwards; decoding
// therefore consumes fields from the high end of the stored bit sequence.
// At most 23 bits are resident because every field is at most 16 bits and a
// refill happens only when fewer than that remain.
struct PRTReverseReader {
    device const uchar *payload;
    uint body_first, cursor, last, reservoir, available, remaining, last_bits;
    bool valid;
};

inline PRTReverseReader prt_reverse_reader(
    device const uchar *payload, uint body_first, uint end, uint meaningful,
    uint last_bits) {
    PRTReverseReader reader;
    reader.payload = payload;
    reader.body_first = body_first;
    reader.cursor = end;
    reader.last = end - 1u;
    reader.reservoir = 0u;
    reader.available = 0u;
    reader.remaining = meaningful;
    reader.last_bits = last_bits;
    reader.valid = true;
    return reader;
}

inline uint prt_reverse_pop(thread PRTReverseReader &reader, uint count) {
    if (!reader.valid || count > reader.remaining) {
        reader.valid = false;
        return 0u;
    }
    while (reader.available < count) {
        if (reader.cursor <= reader.body_first) {
            reader.valid = false;
            return 0u;
        }
        --reader.cursor;
        uint bits = reader.cursor == reader.last ? reader.last_bits : 8u;
        uint value = uint(reader.payload[reader.cursor]) & ((1u << bits) - 1u);
        reader.reservoir = value | (reader.reservoir << bits);
        reader.available += bits;
    }
    reader.remaining -= count;
    reader.available -= count;
    uint value = count == 0u
        ? 0u : (reader.reservoir >> reader.available) & ((1u << count) - 1u);
    reader.reservoir &= reader.available == 0u
        ? 0u : (1u << reader.available) - 1u;
    return value;
}

inline bool prt_entropy_begin(
    device const uchar *payload, uint first, uint end, uint payload_bytes,
    thread uint &state, thread PRTReverseReader &reader) {
    if (end < first || end > payload_bytes || end - first < 2u) return false;
    uint header = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
    uint tail = header & 7u;
    state = header >> 6u;
    uint body_first = first + 2u;
    uint body_bytes = end - body_first;
    if (((header >> 3u) & 7u) != 0u || state >= PRT_STATES
        || (tail != 0u && body_bytes == 0u)) return false;
    uint last_bits = tail == 0u ? 8u : tail;
    if (body_bytes == 0u || (tail != 0u && (uint(payload[end - 1u]) >> tail) != 0u))
        return false;
    uint meaningful = (body_bytes - 1u) * 8u + last_bits;
    reader = prt_reverse_reader(payload, body_first, end, meaningful, last_bits);
    return true;
}

inline bool prt_entropy_pair(
    device const uint *table, thread uint &state,
    thread PRTReverseReader &reader, thread uint &a, thread uint &b) {
    uint code = table[state];
    uint pair = code & 4095u;
    uint bits = (code >> 12u) & 15u;
    state = (code >> 16u) + prt_reverse_pop(reader, bits);
    if (pair == 4095u) {
        uint word = prt_reverse_pop(reader, 13u);
        if (word < 4096u) {
            a = word & 63u;
            b = word >> 6u;
        } else if (word == 4096u) {
            a = prt_reverse_pop(reader, 16u);
            b = prt_reverse_pop(reader, 16u);
        } else {
            reader.valid = false;
            a = b = 0u;
        }
    } else {
        a = pair & 63u;
        b = pair >> 6u;
    }
    return reader.valid && state < PRT_STATES;
}

constant bool prt_macro_requested [[function_constant(2)]];
constant bool prt_macro_enabled = is_function_constant_defined(
    prt_macro_requested) ? prt_macro_requested : false;
constant bool prt_reader32_requested [[function_constant(3)]];
constant bool prt_reader32_enabled = is_function_constant_defined(
    prt_reader32_requested) ? prt_reader32_requested : false;
constant uint prt_partial_leaf_width_requested [[function_constant(5)]];
constant uint prt_partial_leaf_width = is_function_constant_defined(
    prt_partial_leaf_width_requested) ? prt_partial_leaf_width_requested : 64u;
constant uint prt_partial_output_fields_requested [[function_constant(6)]];
constant uint prt_partial_output_fields = is_function_constant_defined(
    prt_partial_output_fields_requested) ? prt_partial_output_fields_requested : 0u;
// Direct partial stores are safe because each partials dispatch group owns a
// disjoint (group, packet) field.  The specialization still initializes every
// field and fences before sparse atomic additions, so mixed dense/sparse masks
// retain the exact modulo-UInt32 reduction contract.
constant bool prt_partial_stores_requested [[function_constant(8)]];
constant bool prt_partial_stores = is_function_constant_defined(
    prt_partial_stores_requested) ? prt_partial_stores_requested : false;
// Optional packet splitting reuses the existing four-SIMD-group owner.  Each
// split gets a disjoint selected-stream subset and the same 2 KiB packet-local
// partial; only the final publication changes to a global atomic merge.
constant uint prt_packet_split_count_requested [[function_constant(9)]];
constant uint prt_packet_split_count = is_function_constant_defined(
    prt_packet_split_count_requested) ? prt_packet_split_count_requested : 1u;
// Each nonterminal reverse-reader refill advances by four bytes.  The next
// eight-byte prime therefore overlaps the previous prime by one word; the
// specialization reuses that word and loads only the newly exposed word.
// Keep the full prime for the final 0...7-byte boundary, where clamping can
// make the old and new aligned windows coincide.
constant bool prt_single_word_refill_requested [[function_constant(10)]];
constant bool prt_single_word_refill = is_function_constant_defined(
    prt_single_word_refill_requested) ? prt_single_word_refill_requested : false;
// Dense packet contributions can be accumulated by the unique lane that owns
// each output scan. Sparse events still use the packet-local atomic partials.
constant bool prt_register_reduction_requested [[function_constant(11)]];
constant bool prt_register_reduction = is_function_constant_defined(
    prt_register_reduction_requested) ? prt_register_reduction_requested : false;
// Plain dense updates are safe in packet_owner2 when the SIMD group fences
// before and after its sparse atomic phase. This keeps the existing 8 KiB
// packet partial and avoids the register footprint of lane-owned sums.
constant bool prt_plain_packet_owner2_requested [[function_constant(12)]];
constant bool prt_plain_packet_owner2 = is_function_constant_defined(
    prt_plain_packet_owner2_requested) ? prt_plain_packet_owner2_requested : false;
// The deterministic internal table factory proves base + (1 << bits) <=
// PRT_STATES for every ordinary and macro transition. This opt-in removes
// only the per-pair state-range compare; payload validity remains checked.
constant bool prt_trusted_decode_table_requested [[function_constant(13)]];
constant bool prt_trusted_decode_table = is_function_constant_defined(
    prt_trusted_decode_table_requested) ? prt_trusted_decode_table_requested : false;
// Diagnostic-only decode coverage mode. It preserves every decoded scalar in
// a lane-local checksum and publishes one reduced checksum per packet instead
// of producing an image or performing per-pair output atomics.
constant bool prt_decode_checksum_requested [[function_constant(14)]];
constant bool prt_decode_checksum = is_function_constant_defined(
    prt_decode_checksum_requested) ? prt_decode_checksum_requested : false;
// FC15 defers reverse-reader refills until the exact state-table bit count is
// known. The eager refill remains the default for all existing pipelines.
constant bool prt_lazy_refill_requested [[function_constant(15)]];
constant bool prt_lazy_refill = is_function_constant_defined(
    prt_lazy_refill_requested) ? prt_lazy_refill_requested : false;
constant bool prt_branchless_pop_requested [[function_constant(16)]];
constant bool prt_branchless_pop = is_function_constant_defined(
    prt_branchless_pop_requested) ? prt_branchless_pop_requested : false;
constant uint prt_refill_threshold_requested [[function_constant(17)]];
constant uint prt_refill_threshold = is_function_constant_defined(
    prt_refill_threshold_requested) ? prt_refill_threshold_requested : 32u;
// Load independent ordinary transition entries before advancing any reader.
// Macro readers retain their queued-pair/lookahead path without preloading.
constant bool prt_phased_table_loads_requested [[function_constant(18)]];
constant bool prt_phased_table_loads = is_function_constant_defined(
    prt_phased_table_loads_requested) ? prt_phased_table_loads_requested : false;
// Supported specializations are 1, 2, 4 and 8, all divisors of 256 pairs.
// Each unrolled iteration retains the ordinary per-pair reduction and stores.
constant uint prt_pair_unroll_requested [[function_constant(19)]];
constant uint prt_pair_unroll = is_function_constant_defined(
    prt_pair_unroll_requested) ? prt_pair_unroll_requested : 1u;

// Four-byte reverse reader. It may prefetch a few bytes below one stream's
// beginning, but never consumes them; the terminal check proves that only the
// declared stream bits affected decoded counts.
struct PRTFastReader {
    device const uchar *payload;
    device const uint *table;
    uint begin, cursor, state, available;
    uint pending_low, pending_high, pending_shift;
    ulong reservoir;
    uint reservoir_low, reservoir_high;
    ulong queued_pairs;
    uint queued_count, remaining_pairs;
    bool valid;
};

inline void prt_fast_prime(thread PRTFastReader &reader) {
    uint low = reader.cursor >= 4u ? reader.cursor - 4u : 0u;
    uint aligned = low & ~3u;
    device const uint *words = reinterpret_cast<device const uint *>(
        reader.payload + aligned);
    reader.pending_low = words[0];
    reader.pending_high = words[1];
    reader.pending_shift = (low & 3u) * 8u;
}

inline void prt_fast_refill(thread PRTFastReader &reader) {
    uint word;
    if (prt_reader32_enabled) {
        uint shift = reader.pending_shift;
        word = shift == 0u
            ? reader.pending_low
            : (reader.pending_low >> shift) | (reader.pending_high << (32u - shift));
    } else {
        ulong joined = ulong(reader.pending_low) | (ulong(reader.pending_high) << 32u);
        word = uint(joined >> reader.pending_shift);
    }
    if (reader.cursor < 4u) {
        uint count = reader.cursor;
        uint mask = count == 0u ? 0u : (1u << (count * 8u)) - 1u;
        word &= mask;
        uint pushed = count * 8u;
        if (prt_reader32_enabled) {
            if (pushed != 0u) {
                reader.reservoir_high = (reader.reservoir_high << pushed)
                    | (reader.reservoir_low >> (32u - pushed));
                reader.reservoir_low = (reader.reservoir_low << pushed) | word;
            }
        } else {
            reader.reservoir = (reader.reservoir << pushed) | ulong(word);
        }
        reader.available += count * 8u;
        reader.cursor = 0u;
    } else {
        if (prt_reader32_enabled) {
            reader.reservoir_high = reader.reservoir_low;
            reader.reservoir_low = word;
        } else {
            reader.reservoir = (reader.reservoir << 32u) | ulong(word);
        }
        reader.available += 32u;
        reader.cursor -= 4u;
    }
    if (prt_single_word_refill && reader.cursor >= 4u) {
        uint low = reader.cursor - 4u;
        uint aligned = low & ~3u;
        device const uint *words = reinterpret_cast<device const uint *>(
            reader.payload + aligned);
        reader.pending_high = reader.pending_low;
        reader.pending_low = words[0];
        reader.pending_shift = (low & 3u) * 8u;
    } else {
        prt_fast_prime(reader);
    }
}

inline uint prt_fast_pop(thread PRTFastReader &reader, uint count) {
    if (!reader.valid || count > reader.available) {
        reader.valid = false;
        return 0u;
    }
    reader.available -= count;
    // The 64-bit reservoir stays below 64 available bits with eager refill.
    // A zero-bit mask already produces zero without a dependent branch.
    if ((!prt_branchless_pop || prt_reader32_enabled) && count == 0u) return 0u;
    uint mask = (1u << count) - 1u;
    if (prt_reader32_enabled) {
        uint shift = reader.available;
        uint value;
        if (shift == 0u) value = reader.reservoir_low;
        else if (shift < 32u) {
            value = (reader.reservoir_low >> shift)
                | (reader.reservoir_high << (32u - shift));
        } else value = reader.reservoir_high >> (shift - 32u);
        return value & mask;
    }
    return uint(reader.reservoir >> reader.available) & mask;
}

inline bool prt_fast_begin(
    device const uchar *payload, uint first, uint end, uint payload_bytes,
    device const uint *table, thread PRTFastReader &reader) {
    reader.payload = payload;
    reader.table = table;
    reader.begin = first;
    reader.cursor = end;
    reader.state = 0u;
    reader.available = 0u;
    reader.pending_low = reader.pending_high = reader.pending_shift = 0u;
    reader.reservoir = 0u;
    if (prt_reader32_enabled) {
        reader.reservoir_low = 0u;
        reader.reservoir_high = 0u;
    }
    if (prt_macro_enabled) {
        reader.queued_pairs = 0u;
        reader.queued_count = 0u;
        reader.remaining_pairs = PRT_INTERVAL / 2u;
    }
    reader.valid = end >= first && end <= payload_bytes
        && end - first >= 2u;
    if (!reader.valid) return false;
    uint header0 = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
    uint tail = header0 & 7u;
    reader.state = header0 >> 6u;
    reader.begin = first + 2u;
    reader.valid = ((header0 >> 3u) & 7u) == 0u
        && reader.state < PRT_STATES
        && (tail == 0u || end > reader.begin);
    if (!reader.valid) return false;
    uint bits = (end - reader.begin) * 8u - ((8u - tail) & 7u);
    if ((bits & 7u) != 0u) {
        reader.available = bits & 7u;
        reader.reservoir = uint(payload[--reader.cursor]);
        if (prt_reader32_enabled) reader.reservoir_low = uint(reader.reservoir);
        reader.valid = uint(reader.reservoir) < (1u << reader.available);
    }
    prt_fast_prime(reader);
    return reader.valid;
}

inline bool prt_fast_pair_code(
    thread PRTFastReader &reader, uint code, thread uint &a, thread uint &b) {
    uint bits = (code >> 12u) & 15u;
    if (prt_lazy_refill) {
        if (reader.available < bits) prt_fast_refill(reader);
    } else if (reader.available < prt_refill_threshold) {
        prt_fast_refill(reader);
    }
    reader.state = (code >> 16u) + prt_fast_pop(reader, bits);
    uint pair = code & 4095u;
    if (pair == 4095u) {
        if (reader.available < 13u) prt_fast_refill(reader);
        uint word = prt_fast_pop(reader, 13u);
        if (word < 4096u) {
            a = word & 63u;
            b = word >> 6u;
        } else if (word == 4096u) {
            if (reader.available < 16u) prt_fast_refill(reader);
            a = prt_fast_pop(reader, 16u);
            if (reader.available < 16u) prt_fast_refill(reader);
            b = prt_fast_pop(reader, 16u);
        } else {
            reader.valid = false;
            a = b = 0u;
        }
    } else {
        a = pair & 63u;
        b = pair >> 6u;
    }
    if (prt_macro_enabled) reader.remaining_pairs -= 1u;
    return reader.valid && (prt_trusted_decode_table || reader.state < PRT_STATES);
}

inline bool prt_fast_pair(
    thread PRTFastReader &reader, thread uint &a, thread uint &b) {
    if (prt_macro_enabled && reader.queued_count != 0u) {
        uint pair = uint(reader.queued_pairs) & 4095u;
        reader.queued_pairs >>= 12u;
        reader.queued_count -= 1u;
        reader.remaining_pairs -= 1u;
        a = pair & 63u;
        b = pair >> 6u;
        return reader.valid && (prt_trusted_decode_table || reader.state < PRT_STATES);
    }
    if (prt_macro_enabled && reader.remaining_pairs >= 3u) {
        int actual_remaining = int(reader.available)
            + 8 * (int(reader.cursor) - int(reader.begin));
        if (actual_remaining >= 4) {
            if (reader.available < 4u) prt_fast_refill(reader);
            uint lookahead = uint(reader.reservoir >> (reader.available - 4u)) & 15u;
            uint macro_index = PRT_STATES
                + 2u * (reader.state * 16u + lookahead);
            ulong entry = ulong(reader.table[macro_index])
                | (ulong(reader.table[macro_index + 1u]) << 32u);
            uint consumed = uint(entry >> 46u) & 7u;
            uint count = uint(entry >> 49u) & 3u;
            if (count != 0u && consumed <= uint(actual_remaining)) {
                (void)prt_fast_pop(reader, consumed);
                reader.state = uint(entry >> 36u) & 1023u;
                reader.queued_pairs = entry & ((1ul << 36u) - 1ul);
                reader.queued_count = count;
                uint pair = uint(reader.queued_pairs) & 4095u;
                reader.queued_pairs >>= 12u;
                reader.queued_count -= 1u;
                reader.remaining_pairs -= 1u;
                a = pair & 63u;
                b = pair >> 6u;
                return reader.valid && (prt_trusted_decode_table || reader.state < PRT_STATES);
            }
        }
    }
    return prt_fast_pair_code(reader, reader.table[reader.state], a, b);
}

inline bool prt_fast_finished(thread PRTFastReader &reader) {
    return reader.valid && reader.cursor <= reader.begin
        && reader.available == 8u * (reader.begin - reader.cursor)
        && reader.state == 0u
        && (!prt_macro_enabled
            || (reader.remaining_pairs == 0u && reader.queued_count == 0u));
}

// Concatenate bounded record offsets without exposing private metadata to the
// host. Adjacent record boundaries intentionally write the same exact value.
kernel void paired_runtime_tans_rebase_offsets(
    device const uint *source [[buffer(0)]],
    device uint *destination [[buffer(1)]],
    constant uint *p [[buffer(2)]],
    uint index [[thread_position_in_grid]]) {
    uint source_streams = p[0], destination_first = p[1], payload_first = p[2];
    if (index <= source_streams)
        destination[destination_first + index] = source[index] + payload_first;
}

// Rebase one record directly into the packed acquisition-wide block-32
// directory. Every stream start is a uint16 delta from its group's uint32
// payload base; a raw fallback is at most 1024 bytes, so a group spans at most
// 32768 bytes. The final record sentinel is checked against the producer's
// host-visible receipt before it is published.
kernel void paired_runtime_tans_rebase_block32_offsets(
    device const uint *source [[buffer(0)]],
    device uchar *destination [[buffer(1)]],
    device atomic_uint *failure [[buffer(2)]],
    constant uint *p [[buffer(3)]],
    uint index [[thread_position_in_grid]]) {
    uint source_streams = p[0], destination_first = p[1];
    uint payload_first = p[2], destination_streams = p[3];
    uint expected_record_payload_bytes = p[4];
    if (index > source_streams) return;
    if (source_streams == 0u || (source_streams & 31u) != 0u
        || (destination_first & 31u) != 0u
        || (destination_streams & 31u) != 0u
        || destination_first > destination_streams
        || source_streams > destination_streams - destination_first) {
        atomic_fetch_or_explicit(failure, 1u, memory_order_relaxed);
        return;
    }
    if (source[0] != 0u || source[source_streams] != expected_record_payload_bytes) {
        atomic_fetch_or_explicit(failure, 2u, memory_order_relaxed);
        return;
    }
    uint group_first = index & ~31u;
    uint value = source[index], base = source[group_first];
    bool invalid_span = value < base || value - base > 32768u;
    if (index > 0u) {
        uint previous = source[index - 1u];
        invalid_span = invalid_span || value < previous || value - previous > 1024u;
    }
    if (index > 0u && (index & 31u) == 0u) {
        uint previous_group_base = source[index - 32u];
        invalid_span = invalid_span || value < previous_group_base
            || value - previous_group_base > 32768u;
    }
    if (invalid_span || value > 0xffffffffu - payload_first) {
        atomic_fetch_or_explicit(failure, 4u, memory_order_relaxed);
        return;
    }
    uint destination_stream = destination_first + index;
    uint base_count = (destination_streams >> 5u) + 1u;
    device uint *bases = reinterpret_cast<device uint *>(destination);
    device ushort *starts = reinterpret_cast<device ushort *>(
        destination + ulong(base_count) * sizeof(uint));
    if ((index & 31u) == 0u)
        bases[destination_stream >> 5u] = payload_first + value;
    starts[destination_stream] = ushort(value - base);
}

// Exact diffraction pattern at one scan of one flat 16K record. The kernel
// decodes only the dependency prefix ending at the selected scan's pair and
// widens the native count to uint32. It has no archive or HDF5 dependency.
kernel void paired_runtime_tans_selected_dp(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device uint *output [[buffer(4)]],
    device atomic_uint *failure [[buffer(5)]],
    constant uint *p [[buffer(6)]],
    uint pixel [[thread_position_in_grid]]) {
    uint pixels = p[0], packets = p[1], scan = p[2], payload_bytes = p[3];
    if (pixel >= pixels) return;
    if (scan >= packets * PRT_INTERVAL) {
        atomic_store_explicit(failure, 20u, memory_order_relaxed);
        return;
    }
    uint packet = scan / PRT_INTERVAL;
    uint local = scan % PRT_INTERVAL;
    uint stream = packet * pixels + pixel;
    uint total_streams = pixels * packets;
    uint first = prt_source_offset(offsets, stream, total_streams);
    uint end = prt_source_offset(offsets, stream + 1u, total_streams);
    if (end < first || end > payload_bytes) {
        atomic_store_explicit(failure, 21u, memory_order_relaxed);
        return;
    }
    uint mode = uint(modes[stream]);
    if (mode == 253u) {
        if (first != end) atomic_store_explicit(failure, 22u, memory_order_relaxed);
        output[pixel] = 0u;
        return;
    }
    if (mode == 255u) {
        if (end - first != 2u) {
            atomic_store_explicit(failure, 23u, memory_order_relaxed);
            return;
        }
        output[pixel] = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
        return;
    }
    if (mode == 254u) {
        if (end - first != 2u * PRT_INTERVAL) {
            atomic_store_explicit(failure, 24u, memory_order_relaxed);
            return;
        }
        uint at = first + 2u * local;
        output[pixel] = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
        return;
    }
    if (mode == 252u) {
        if (((end - first) & 1u) != 0u) {
            atomic_store_explicit(failure, 25u, memory_order_relaxed);
            return;
        }
        uint value = 0u, previous = 0u;
        bool has_previous = false;
        for (uint cursor = first; cursor < end; cursor += 2u) {
            uint event = uint(payload[cursor]) | (uint(payload[cursor + 1u]) << 8u);
            uint position = event >> 7u;
            if (position >= PRT_INTERVAL || (has_previous && position <= previous)) {
                atomic_store_explicit(failure, 26u, memory_order_relaxed);
                return;
            }
            if (position == local) value = (event & 127u) + 1u;
            previous = position;
            has_previous = true;
        }
        output[pixel] = value;
        return;
    }
    if (!prt_entropy_mode(mode)) {
        atomic_store_explicit(failure, 27u, memory_order_relaxed);
        return;
    }
    uint state = 0u;
    PRTFastReader reader;
    device const uint *table = decoding + prt_entropy_model(mode) * PRT_STATES;
    if (!prt_fast_begin(payload, first, end, payload_bytes, table, reader)) {
        atomic_store_explicit(failure, 28u, memory_order_relaxed);
        return;
    }
    uint target_pair = local >> 1u;
    uint a = 0u, b = 0u;
    for (uint pair = 0u; pair <= target_pair; ++pair) {
        if (!prt_fast_pair(reader, a, b)) {
            atomic_store_explicit(failure, 29u, memory_order_relaxed);
            return;
        }
    }
    output[pixel] = (local & 1u) == 0u ? a : b;
}

// Exact detector-mask delta for one flat 16K record. Four SIMD groups share a
// threadgroup; each owns one 512-scan packet and a disjoint 2 KiB scratch
// slice. Dense streams reduce within that SIMD, sparse streams scatter their
// at-most-two events atomically, and every output scan is written once.
kernel void paired_runtime_tans_detector_packet_owner(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device const uint *selected [[buffer(4)]],
    device const int *coefficients [[buffer(5)]],
    device uint *output [[buffer(6)]],
    device atomic_uint *failure [[buffer(7)]],
    constant uint *p [[buffer(8)]],
    uint packet_group [[threadgroup_position_in_grid]],
    uint thread_id [[thread_index_in_threadgroup]]) {
    uint simd = thread_id >> 5u;
    uint lane = thread_id & 31u;
    uint pixels = p[0], packets = p[1], changed = p[2];
    uint output_first = p[3], payload_bytes = p[4];
    bool include_sparse = p[5] != 0u;
    uint packet = packet_group * 4u + simd;
    if (packet >= packets) return;
    threadgroup atomic_int partial_storage[4u * PRT_INTERVAL];
    threadgroup atomic_int *partials = partial_storage + simd * PRT_INTERVAL;
    for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u)
        atomic_store_explicit(partials + scan, 0, memory_order_relaxed);
    simdgroup_barrier(mem_flags::mem_threadgroup);

    for (uint base = 0u; base < changed; base += 32u) {
        uint ordinal = base + lane;
        bool active = ordinal < changed;
        uint pixel = active ? selected[ordinal] : 0u;
        if (active && pixel >= pixels) {
            atomic_store_explicit(failure, 30u, memory_order_relaxed);
            active = false;
        }
        int coefficient = active ? coefficients[ordinal] : 0;
        uint stream = packet * pixels + pixel;
        uint total_streams = pixels * packets;
        uint first = active ? prt_source_offset(offsets, stream, total_streams) : 0u;
        uint end = active ? prt_source_offset(offsets, stream + 1u, total_streams) : 0u;
        uint mode = active ? uint(modes[stream]) : 253u;
        if (active && (end < first || end > payload_bytes)) {
            atomic_store_explicit(failure, 31u, memory_order_relaxed);
            active = false;
            mode = 253u;
        }
        bool sparse = include_sparse && active && mode == 252u;
        bool dense = active && mode != 252u && mode != 253u;
        uint constant_value = 0u, state = 0u;
        PRTFastReader reader;
        bool entropy = dense && prt_entropy_mode(mode);
        if (dense && mode == 255u) {
            if (end - first == 2u)
                constant_value = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
            else active = dense = false;
        } else if (dense && mode == 254u) {
            if (end - first != 2u * PRT_INTERVAL) active = dense = false;
        } else if (entropy) {
            device const uint *table = decoding + prt_entropy_model(mode) * PRT_STATES;
            if (!prt_fast_begin(payload, first, end, payload_bytes, table, reader))
                active = dense = entropy = false;
        } else if (dense) {
            active = dense = false;
        }
        if (!active && ordinal < changed)
            atomic_store_explicit(failure, 32u, memory_order_relaxed);

        if (simd_any(dense)) {
            for (uint pair = 0u; pair < PRT_INTERVAL / 2u; ++pair) {
                uint a = 0u, b = 0u;
                if (dense) {
                    if (entropy) {
                        if (!prt_fast_pair(reader, a, b)) {
                            atomic_store_explicit(failure, 33u, memory_order_relaxed);
                            dense = false;
                        }
                    } else if (mode == 254u) {
                        uint at = first + 4u * pair;
                        a = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
                        b = uint(payload[at + 2u]) | (uint(payload[at + 3u]) << 8u);
                    } else {
                        a = b = constant_value;
                    }
                }
                int sum_a = simd_sum(int(a) * coefficient);
                int sum_b = simd_sum(int(b) * coefficient);
                if (lane == 0u) {
                    atomic_fetch_add_explicit(
                        partials + 2u * pair, sum_a, memory_order_relaxed);
                    atomic_fetch_add_explicit(
                        partials + 2u * pair + 1u, sum_b, memory_order_relaxed);
                }
            }
            if (entropy && dense && !prt_fast_finished(reader))
                atomic_store_explicit(failure, 34u, memory_order_relaxed);
        }
        if (sparse) {
            if (((end - first) & 1u) != 0u) {
                atomic_store_explicit(failure, 35u, memory_order_relaxed);
            } else {
                uint previous = 0u;
                bool has_previous = false;
                for (uint cursor = first; cursor < end; cursor += 2u) {
                    uint event = uint(payload[cursor])
                        | (uint(payload[cursor + 1u]) << 8u);
                    uint position = event >> 7u;
                    if (position >= PRT_INTERVAL || (has_previous && position <= previous)) {
                        atomic_store_explicit(failure, 36u, memory_order_relaxed);
                        break;
                    }
                    int contribution = int((event & 127u) + 1u) * coefficient;
                    atomic_fetch_add_explicit(
                        partials + position, contribution, memory_order_relaxed);
                    previous = position;
                    has_previous = true;
                }
            }
        }
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
    uint packet_first = output_first + packet * PRT_INTERVAL;
    for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u)
        output[packet_first + scan] += uint(
            atomic_load_explicit(partials + scan, memory_order_relaxed));
}

// Sparse streams have at most two events in the runtime ABI. Give every
// changed-pixel/packet stream its own thread so sparse ADF boundaries do not
// serialize behind dense packet-owner batches.
kernel void paired_runtime_tans_detector_sparse_scatter(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *selected [[buffer(3)]],
    device const int *coefficients [[buffer(4)]],
    device atomic_uint *output [[buffer(5)]],
    device atomic_uint *failure [[buffer(6)]],
    constant uint *p [[buffer(7)]],
    uint job [[thread_position_in_grid]]) {
    uint pixels = p[0], packets = p[1], changed = p[2], payload_bytes = p[3];
    if (job >= packets * changed) return;
    uint packet = job / changed;
    uint ordinal = job - packet * changed;
    uint pixel = selected[ordinal];
    if (pixel >= pixels) {
        atomic_store_explicit(failure, 50u, memory_order_relaxed);
        return;
    }
    uint stream = packet * pixels + pixel;
    if (modes[stream] != 252u) return;
    uint total_streams = pixels * packets;
    uint first = prt_source_offset(offsets, stream, total_streams);
    uint end = prt_source_offset(offsets, stream + 1u, total_streams);
    if (end < first || end > payload_bytes || ((end - first) & 1u) != 0u) {
        atomic_store_explicit(failure, 51u, memory_order_relaxed);
        return;
    }
    uint previous = 0u;
    bool has_previous = false;
    uint sign = uint(coefficients[ordinal]);
    for (uint cursor = first; cursor < end; cursor += 2u) {
        uint event = uint(payload[cursor]) | (uint(payload[cursor + 1u]) << 8u);
        uint position = event >> 7u;
        if (position >= PRT_INTERVAL || (has_previous && position <= previous)) {
            atomic_store_explicit(failure, 52u, memory_order_relaxed);
            return;
        }
        uint contribution = ((event & 127u) + 1u) * sign;
        atomic_fetch_add_explicit(
            output + packet * PRT_INTERVAL + position, contribution,
            memory_order_relaxed);
        previous = position;
        has_previous = true;
    }
}

// Benchmark-only selected-stream mode histogram. The 256 counters are the only
// CPU-readable result; the acquisition-wide private mode array stays resident.
kernel void paired_runtime_tans_detector_mode_histogram(
    device const uchar *modes [[buffer(0)]],
    device const uint *selected [[buffer(1)]],
    device atomic_uint *histogram [[buffer(2)]],
    constant uint *p [[buffer(3)]],
    uint job [[thread_position_in_grid]]) {
    uint pixels = p[0], packets = p[1], changed = p[2];
    if (job >= packets * changed) return;
    uint packet = job / changed;
    uint ordinal = job - packet * changed;
    uint pixel = selected[ordinal];
    if (pixel >= pixels) return;
    uint mode = uint(modes[packet * pixels + pixel]);
    atomic_fetch_add_explicit(histogram + mode, 1u, memory_order_relaxed);
}

constant uint prt_streams_per_lane_requested [[function_constant(0)]];
constant uint prt_streams_per_lane = is_function_constant_defined(
    prt_streams_per_lane_requested) ? prt_streams_per_lane_requested : 2u;
constant bool prt_plain_scratch_requested [[function_constant(1)]];
constant bool prt_plain_scratch = is_function_constant_defined(
    prt_plain_scratch_requested) ? prt_plain_scratch_requested : false;

// Independent detector streams per lane expose tANS instruction-level
// parallelism and share SIMD reductions. Exact sparse alternatives remain
// event-driven and share the same packet-local accumulator. The production
// specializations use two or four streams per lane.
kernel void paired_runtime_tans_detector_packet_owner2(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device const uint *selected [[buffer(4)]],
    device const int *coefficients [[buffer(5)]],
    device uint *output [[buffer(6)]],
    device atomic_uint *failure [[buffer(7)]],
    constant uint *p [[buffer(8)]],
    uint packet_group [[threadgroup_position_in_grid]],
    uint thread_id [[thread_index_in_threadgroup]]) {
    uint simd = thread_id >> 5u;
    uint lane = thread_id & 31u;
    uint pixels = p[0], packets = p[1], changed = p[2];
    uint output_first = p[3], payload_bytes = p[4];
    bool include_sparse = p[5] != 0u;
    if (prt_decode_checksum && prt_packet_split_count != 1u) {
        if (thread_id == 0u) atomic_store_explicit(failure, 100u, memory_order_relaxed);
        return;
    }
    if (prt_packet_split_count != 1u && prt_packet_split_count != 2u
        && prt_packet_split_count != 4u && prt_packet_split_count != 8u) {
        if (thread_id == 0u) atomic_store_explicit(failure, 98u, memory_order_relaxed);
        return;
    }
    uint split_index = packet_group % prt_packet_split_count;
    uint packet_batch = packet_group / prt_packet_split_count;
    uint packet = packet_batch * 4u + simd;
    if (packet >= packets) return;
    if (prt_register_reduction && prt_plain_packet_owner2) {
        if (thread_id == 0u) atomic_store_explicit(failure, 99u, memory_order_relaxed);
        return;
    }
    threadgroup uint partial_storage[4u * PRT_INTERVAL];
    threadgroup uint *partials = partial_storage + simd * PRT_INTERVAL;
    threadgroup atomic_uint *atomic_partials =
        reinterpret_cast<threadgroup atomic_uint *>(partials);
    uint decode_checksum = 0u;
    uint dense_accum[16];
    if (prt_register_reduction) {
        #pragma unroll
        for (uint slot = 0u; slot < 16u; ++slot)
            dense_accum[slot] = 0u;
    }
    if (!prt_decode_checksum) {
        for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u) {
            if (prt_plain_packet_owner2)
                partials[scan] = 0u;
            else
                atomic_store_explicit(atomic_partials + scan, 0u, memory_order_relaxed);
        }
        simdgroup_barrier(mem_flags::mem_threadgroup);
    }

    uint base = split_index * 32u * prt_streams_per_lane;
    uint base_stride = prt_packet_split_count * 32u * prt_streams_per_lane;
    for (; base < changed; base += base_stride) {
        bool active[4], sparse[4], dense[4], entropy[4];
        uint first[4], end[4], mode[4], constant_value[4];
        int coefficient[4];
        PRTFastReader reader[4];
        #pragma unroll
        for (uint j = 0u; j < prt_streams_per_lane; ++j) {
            uint ordinal = base + j * 32u + lane;
            active[j] = ordinal < changed;
            uint pixel = active[j] ? selected[ordinal] : 0u;
            if (active[j] && pixel >= pixels) {
                atomic_store_explicit(failure, 60u, memory_order_relaxed);
                active[j] = false;
            }
            coefficient[j] = active[j] ? coefficients[ordinal] : 0;
            uint stream = packet * pixels + pixel;
            uint total_streams = pixels * packets;
            first[j] = active[j] ? prt_source_offset(offsets, stream, total_streams) : 0u;
            end[j] = active[j]
                ? prt_source_offset(offsets, stream + 1u, total_streams) : 0u;
            mode[j] = active[j] ? uint(modes[stream]) : 253u;
            if (active[j] && (end[j] < first[j] || end[j] > payload_bytes)) {
                atomic_store_explicit(failure, 61u, memory_order_relaxed);
                active[j] = false;
                mode[j] = 253u;
            }
            sparse[j] = include_sparse && active[j] && mode[j] == 252u;
            dense[j] = active[j] && mode[j] != 252u && mode[j] != 253u;
            entropy[j] = dense[j] && prt_entropy_mode(mode[j]);
            constant_value[j] = 0u;
            if (dense[j] && mode[j] == 255u) {
                if (end[j] - first[j] == 2u)
                    constant_value[j] = uint(payload[first[j]])
                        | (uint(payload[first[j] + 1u]) << 8u);
                else active[j] = dense[j] = false;
            } else if (dense[j] && mode[j] == 254u) {
                if (end[j] - first[j] != 2u * PRT_INTERVAL)
                    active[j] = dense[j] = false;
            } else if (entropy[j]) {
                uint table_stride = prt_macro_enabled ? 33792u : PRT_STATES;
                device const uint *table = decoding
                    + prt_entropy_model(mode[j]) * table_stride;
                if (!prt_fast_begin(
                    payload, first[j], end[j], payload_bytes, table, reader[j]))
                    active[j] = dense[j] = entropy[j] = false;
            } else if (dense[j]) {
                active[j] = dense[j] = false;
            }
            if (!active[j] && ordinal < changed)
                atomic_store_explicit(failure, 62u, memory_order_relaxed);
        }
        bool any_dense = false;
        #pragma unroll
        for (uint j = 0u; j < prt_streams_per_lane; ++j)
            any_dense = any_dense || dense[j];
        if (simd_any(any_dense)) {
            for (uint pair_base = 0u; pair_base < PRT_INTERVAL / 2u;
                 pair_base += prt_pair_unroll) {
                #pragma unroll
                for (uint pair_offset = 0u; pair_offset < prt_pair_unroll; ++pair_offset) {
                    uint pair = pair_base + pair_offset;
                    uint sum_a = 0u, sum_b = 0u;
                    uint preloaded_code[4];
                    if (prt_phased_table_loads && !prt_macro_enabled) {
                        #pragma unroll
                        for (uint j = 0u; j < prt_streams_per_lane; ++j) {
                            // The same guards protect the original pair call.
                            // Failed readers have dense cleared before the next pair.
                            if (dense[j] && entropy[j])
                                preloaded_code[j] = reader[j].table[reader[j].state];
                        }
                    }
                    #pragma unroll
                    for (uint j = 0u; j < prt_streams_per_lane; ++j) {
                        uint a = 0u, b = 0u;
                        if (dense[j]) {
                            if (entropy[j]) {
                                bool decoded = prt_phased_table_loads && !prt_macro_enabled
                                    ? prt_fast_pair_code(reader[j], preloaded_code[j], a, b)
                                    : prt_fast_pair(reader[j], a, b);
                                if (!decoded) {
                                    atomic_store_explicit(failure, 63u, memory_order_relaxed);
                                    dense[j] = false;
                                }
                            } else if (mode[j] == 254u) {
                                uint at = first[j] + 4u * pair;
                                a = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
                                b = uint(payload[at + 2u]) | (uint(payload[at + 3u]) << 8u);
                            } else {
                                a = b = constant_value[j];
                            }
                        }
                        sum_a += uint(int(a) * coefficient[j]);
                        sum_b += uint(int(b) * coefficient[j]);
                    }
                    if (prt_decode_checksum) {
                        decode_checksum += sum_a + sum_b;
                    } else {
                        sum_a = simd_sum(sum_a);
                        sum_b = simd_sum(sum_b);
                    }
                    if (!prt_decode_checksum && lane == 0u) {
                        if (prt_plain_packet_owner2) {
                            partials[2u * pair] += sum_a;
                            partials[2u * pair + 1u] += sum_b;
                        } else if (!prt_register_reduction) {
                            atomic_fetch_add_explicit(
                                atomic_partials + 2u * pair, sum_a, memory_order_relaxed);
                            atomic_fetch_add_explicit(
                                atomic_partials + 2u * pair + 1u, sum_b, memory_order_relaxed);
                        }
                    }
                    if (prt_register_reduction && (lane >> 1u) == (pair & 15u)) {
                        dense_accum[pair >> 4u] += (lane & 1u) == 0u ? sum_a : sum_b;
                    }
                }
            }
            #pragma unroll
            for (uint j = 0u; j < prt_streams_per_lane; ++j)
                if (entropy[j] && dense[j] && !prt_fast_finished(reader[j]))
                    atomic_store_explicit(failure, 64u, memory_order_relaxed);
        }
        bool any_sparse = false;
        #pragma unroll
        for (uint j = 0u; j < prt_streams_per_lane; ++j)
            any_sparse = any_sparse || sparse[j];
        if (prt_plain_packet_owner2 && simd_any(any_sparse))
            simdgroup_barrier(mem_flags::mem_threadgroup);
        #pragma unroll
        for (uint j = 0u; j < prt_streams_per_lane; ++j) {
            if (!sparse[j]) continue;
            if (((end[j] - first[j]) & 1u) != 0u) {
                atomic_store_explicit(failure, 65u, memory_order_relaxed);
                continue;
            }
            uint previous = 0u;
            bool has_previous = false;
            for (uint cursor = first[j]; cursor < end[j]; cursor += 2u) {
                uint event = uint(payload[cursor])
                    | (uint(payload[cursor + 1u]) << 8u);
                uint position = event >> 7u;
                if (position >= PRT_INTERVAL || (has_previous && position <= previous)) {
                    atomic_store_explicit(failure, 66u, memory_order_relaxed);
                    break;
                }
                int contribution = int((event & 127u) + 1u) * coefficient[j];
                if (prt_decode_checksum)
                    decode_checksum += uint(contribution);
                else
                    atomic_fetch_add_explicit(
                        atomic_partials + position, uint(contribution), memory_order_relaxed);
                previous = position;
                has_previous = true;
            }
        }
        if (prt_plain_packet_owner2 && simd_any(any_sparse))
            simdgroup_barrier(mem_flags::mem_threadgroup);
    }
    if (prt_decode_checksum) {
        uint packet_checksum = simd_sum(decode_checksum);
        if (lane == 0u) output[packet] = packet_checksum;
        return;
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
    uint packet_first = output_first + packet * PRT_INTERVAL;
    if (prt_packet_split_count == 1u) {
        for (uint slot = 0u; slot < 16u; ++slot) {
            uint scan = lane + 32u * slot;
            uint contribution = prt_plain_packet_owner2
                ? partials[scan]
                : uint(atomic_load_explicit(atomic_partials + scan, memory_order_relaxed));
            if (prt_register_reduction)
                contribution += dense_accum[slot];
            output[packet_first + scan] += contribution;
        }
    } else {
        device atomic_uint *atomic_output = reinterpret_cast<device atomic_uint *>(output);
        for (uint slot = 0u; slot < 16u; ++slot) {
            uint scan = lane + 32u * slot;
            uint contribution = prt_plain_packet_owner2
                ? partials[scan]
                : uint(atomic_load_explicit(atomic_partials + scan, memory_order_relaxed));
            if (prt_register_reduction)
                contribution += dense_accum[slot];
            atomic_fetch_add_explicit(
                atomic_output + packet_first + scan,
                contribution,
                memory_order_relaxed);
        }
    }
}

// Dense-only packet owner used with the independent sparse scatter. Each lane
// advances through its strided selected ordinals until it owns a dense stream,
// so sparse and zero gaps cannot force an otherwise idle lane through 256 pair
// iterations. One stream per lane keeps the experimental register footprint
// bounded while preserving the packet-local exact integer reduction.
kernel void paired_runtime_tans_detector_dense_compaction(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device const uint *selected [[buffer(4)]],
    device const int *coefficients [[buffer(5)]],
    device uint *output [[buffer(6)]],
    device atomic_uint *failure [[buffer(7)]],
    constant uint *p [[buffer(8)]],
    uint packet_group [[threadgroup_position_in_grid]],
    uint thread_id [[thread_index_in_threadgroup]]) {
    uint simd = thread_id >> 5u;
    uint lane = thread_id & 31u;
    uint pixels = p[0], packets = p[1], changed = p[2];
    uint output_first = p[3], payload_bytes = p[4];
    uint packet = packet_group * 4u + simd;
    if (packet >= packets) return;
    threadgroup uint partial_storage[4u * PRT_INTERVAL];
    threadgroup uint *partials = partial_storage + simd * PRT_INTERVAL;
    threadgroup atomic_uint *atomic_partials =
        reinterpret_cast<threadgroup atomic_uint *>(partials);
    for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u) {
        if (prt_plain_scratch) partials[scan] = 0u;
        else atomic_store_explicit(atomic_partials + scan, 0u, memory_order_relaxed);
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);

    uint ordinal = lane;
    while (true) {
        bool dense = false, entropy = false;
        uint first = 0u, end = 0u, mode = 253u, constant_value = 0u;
        int coefficient = 0;
        PRTFastReader reader;
        while (ordinal < changed && !dense) {
            uint candidate = ordinal;
            ordinal += 32u;
            uint pixel = selected[candidate];
            if (pixel >= pixels) {
                atomic_store_explicit(failure, 70u, memory_order_relaxed);
                continue;
            }
            uint stream = packet * pixels + pixel;
            uint total_streams = pixels * packets;
            first = prt_source_offset(offsets, stream, total_streams);
            end = prt_source_offset(offsets, stream + 1u, total_streams);
            mode = uint(modes[stream]);
            if (end < first || end > payload_bytes) {
                atomic_store_explicit(failure, 71u, memory_order_relaxed);
                continue;
            }
            if (mode == 252u || mode == 253u) continue;
            coefficient = coefficients[candidate];
            entropy = prt_entropy_mode(mode);
            if (mode == 255u) {
                if (end - first != 2u) {
                    atomic_store_explicit(failure, 72u, memory_order_relaxed);
                    continue;
                }
                constant_value = uint(payload[first])
                    | (uint(payload[first + 1u]) << 8u);
            } else if (mode == 254u) {
                if (end - first != 2u * PRT_INTERVAL) {
                    atomic_store_explicit(failure, 72u, memory_order_relaxed);
                    continue;
                }
            } else if (entropy) {
                device const uint *table = decoding + prt_entropy_model(mode) * PRT_STATES;
                if (!prt_fast_begin(payload, first, end, payload_bytes, table, reader)) {
                    atomic_store_explicit(failure, 72u, memory_order_relaxed);
                    continue;
                }
            } else {
                atomic_store_explicit(failure, 72u, memory_order_relaxed);
                continue;
            }
            dense = true;
        }
        if (!simd_any(dense)) break;
        for (uint pair = 0u; pair < PRT_INTERVAL / 2u; ++pair) {
            uint a = 0u, b = 0u;
            if (dense) {
                if (entropy) {
                    if (!prt_fast_pair(reader, a, b)) {
                        atomic_store_explicit(failure, 73u, memory_order_relaxed);
                        dense = false;
                    }
                } else if (mode == 254u) {
                    uint at = first + 4u * pair;
                    a = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
                    b = uint(payload[at + 2u]) | (uint(payload[at + 3u]) << 8u);
                } else {
                    a = b = constant_value;
                }
            }
            int sum_a = simd_sum(int(a) * coefficient);
            int sum_b = simd_sum(int(b) * coefficient);
            if (lane == 0u) {
                if (prt_plain_scratch) {
                    partials[2u * pair] += uint(sum_a);
                    partials[2u * pair + 1u] += uint(sum_b);
                } else {
                    atomic_fetch_add_explicit(
                        atomic_partials + 2u * pair, uint(sum_a), memory_order_relaxed);
                    atomic_fetch_add_explicit(
                        atomic_partials + 2u * pair + 1u, uint(sum_b),
                        memory_order_relaxed);
                }
            }
        }
        if (entropy && dense && !prt_fast_finished(reader))
            atomic_store_explicit(failure, 74u, memory_order_relaxed);
    }
    simdgroup_barrier(mem_flags::mem_threadgroup);
    uint packet_first = output_first + packet * PRT_INTERVAL;
    for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u) {
        uint value = prt_plain_scratch
            ? partials[scan]
            : atomic_load_explicit(atomic_partials + scan, memory_order_relaxed);
        output[packet_first + scan] += value;
    }
}

// Four SIMD groups cooperate on one packet while retaining the same 8 KiB
// threadgroup footprint as the four-packet owner. Each SIMD owns disjoint
// detector ordinals and a disjoint 512-scan partial; the whole threadgroup
// publishes each exact output once after reducing those four partials.
kernel void paired_runtime_tans_detector_cooperative(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device const uint *selected [[buffer(4)]],
    device const int *coefficients [[buffer(5)]],
    device uint *output [[buffer(6)]],
    device atomic_uint *failure [[buffer(7)]],
    constant uint *p [[buffer(8)]],
    uint packet [[threadgroup_position_in_grid]],
    uint thread_id [[thread_index_in_threadgroup]]) {
    uint simd = thread_id >> 5u;
    uint lane = thread_id & 31u;
    uint pixels = p[0], packets = p[1], changed = p[2];
    uint output_first = p[3], payload_bytes = p[4];
    bool include_sparse = p[5] != 0u;
    if (packet >= packets) return;
    threadgroup uint partial_storage[4u * PRT_INTERVAL];
    threadgroup uint *partials = partial_storage + simd * PRT_INTERVAL;
    for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u)
        partials[scan] = 0u;
    threadgroup_barrier(mem_flags::mem_threadgroup);

    for (uint base = simd * 32u; base < changed; base += 128u) {
        uint ordinal = base + lane;
        bool active = ordinal < changed;
        uint pixel = active ? selected[ordinal] : 0u;
        if (active && pixel >= pixels) {
            atomic_store_explicit(failure, 80u, memory_order_relaxed);
            active = false;
        }
        int coefficient = active ? coefficients[ordinal] : 0;
        uint stream = packet * pixels + pixel;
        uint total_streams = pixels * packets;
        uint first = active ? prt_source_offset(offsets, stream, total_streams) : 0u;
        uint end = active ? prt_source_offset(offsets, stream + 1u, total_streams) : 0u;
        uint mode = active ? uint(modes[stream]) : 253u;
        if (active && (end < first || end > payload_bytes)) {
            atomic_store_explicit(failure, 81u, memory_order_relaxed);
            active = false;
            mode = 253u;
        }
        bool sparse = include_sparse && active && mode == 252u;
        bool dense = active && mode != 252u && mode != 253u;
        uint constant_value = 0u;
        PRTFastReader reader;
        bool entropy = dense && prt_entropy_mode(mode);
        if (dense && mode == 255u) {
            if (end - first == 2u)
                constant_value = uint(payload[first]) | (uint(payload[first + 1u]) << 8u);
            else active = dense = false;
        } else if (dense && mode == 254u) {
            if (end - first != 2u * PRT_INTERVAL) active = dense = false;
        } else if (entropy) {
            device const uint *table = decoding + prt_entropy_model(mode) * PRT_STATES;
            if (!prt_fast_begin(payload, first, end, payload_bytes, table, reader))
                active = dense = entropy = false;
        } else if (dense) {
            active = dense = false;
        }
        if (!active && ordinal < changed)
            atomic_store_explicit(failure, 82u, memory_order_relaxed);

        if (simd_any(dense)) {
            for (uint pair = 0u; pair < PRT_INTERVAL / 2u; ++pair) {
                uint a = 0u, b = 0u;
                if (dense) {
                    if (entropy) {
                        if (!prt_fast_pair(reader, a, b)) {
                            atomic_store_explicit(failure, 83u, memory_order_relaxed);
                            dense = false;
                        }
                    } else if (mode == 254u) {
                        uint at = first + 4u * pair;
                        a = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
                        b = uint(payload[at + 2u]) | (uint(payload[at + 3u]) << 8u);
                    } else {
                        a = b = constant_value;
                    }
                }
                uint sum_a = simd_sum(uint(int(a) * coefficient));
                uint sum_b = simd_sum(uint(int(b) * coefficient));
                if (lane == 0u) {
                    partials[2u * pair] += sum_a;
                    partials[2u * pair + 1u] += sum_b;
                }
            }
            if (entropy && dense && !prt_fast_finished(reader))
                atomic_store_explicit(failure, 84u, memory_order_relaxed);
        }
        if (sparse) {
            if (((end - first) & 1u) != 0u) {
                atomic_store_explicit(failure, 85u, memory_order_relaxed);
            } else {
                uint previous = 0u;
                bool has_previous = false;
                for (uint cursor = first; cursor < end; cursor += 2u) {
                    uint event = uint(payload[cursor])
                        | (uint(payload[cursor + 1u]) << 8u);
                    uint position = event >> 7u;
                    if (position >= PRT_INTERVAL
                        || (has_previous && position <= previous)) {
                        atomic_store_explicit(failure, 86u, memory_order_relaxed);
                        break;
                    }
                    uint contribution = uint(
                        int((event & 127u) + 1u) * coefficient);
                    atomic_fetch_add_explicit(
                        reinterpret_cast<threadgroup atomic_uint *>(partials) + position,
                        contribution, memory_order_relaxed);
                    previous = position;
                    has_previous = true;
                }
            }
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint packet_first = output_first + packet * PRT_INTERVAL;
    for (uint scan = thread_id; scan < PRT_INTERVAL; scan += 128u) {
        uint value = partial_storage[scan]
            + partial_storage[PRT_INTERVAL + scan]
            + partial_storage[2u * PRT_INTERVAL + scan]
            + partial_storage[3u * PRT_INTERVAL + scan];
        output[packet_first + scan] += value;
    }
}

// High-parallelism detector delta for medium masks. One SIMD owns 64 changed
// detector pixels in one packet, decodes two independent streams per lane, and
// publishes an independent 512-scan partial.
kernel void paired_runtime_tans_detector_partials(
    device const uchar *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *modes [[buffer(2)]],
    device const uint *decoding [[buffer(3)]],
    device const uint *selected [[buffer(4)]],
    device const int *coefficients [[buffer(5)]],
    device atomic_uint *partials [[buffer(6)]],
    device atomic_uint *failure [[buffer(7)]],
    constant uint *p [[buffer(8)]],
    uint2 group [[threadgroup_position_in_grid]],
    uint lane [[thread_index_in_simdgroup]]) {
    uint pixels = p[0], packets = p[1], changed = p[2], groups = p[3];
    uint payload_bytes = p[4];
    if (group.x >= groups || group.y >= packets) return;
    if (prt_partial_leaf_width != 16u && prt_partial_leaf_width != 32u
        && prt_partial_leaf_width != 64u) {
        if (lane == 0u) atomic_store_explicit(failure, 47u, memory_order_relaxed);
        return;
    }
    bool active[2], sparse[2], dense[2], entropy[2];
    uint first[2], end[2], mode[2], constant_value[2];
    int coefficient[2];
    PRTFastReader reader[2];
    #pragma unroll
    for (uint j = 0u; j < 2u; ++j) {
        uint local = j * 32u + lane;
        uint ordinal = group.x * prt_partial_leaf_width + local;
        active[j] = local < prt_partial_leaf_width && ordinal < changed;
        uint pixel = active[j] ? selected[ordinal] : 0u;
        if (active[j] && pixel >= pixels) {
            atomic_store_explicit(failure, 40u, memory_order_relaxed);
            active[j] = false;
        }
        coefficient[j] = active[j] ? coefficients[ordinal] : 0;
        uint stream = group.y * pixels + pixel;
        uint total_streams = pixels * packets;
        first[j] = active[j] ? prt_source_offset(offsets, stream, total_streams) : 0u;
        end[j] = active[j]
            ? prt_source_offset(offsets, stream + 1u, total_streams) : 0u;
        mode[j] = active[j] ? uint(modes[stream]) : 253u;
        if (active[j] && (end[j] < first[j] || end[j] > payload_bytes)) {
            atomic_store_explicit(failure, 41u, memory_order_relaxed);
            active[j] = false;
            mode[j] = 253u;
        }
        sparse[j] = active[j] && mode[j] == 252u;
        dense[j] = active[j] && mode[j] != 252u && mode[j] != 253u;
        entropy[j] = dense[j] && prt_entropy_mode(mode[j]);
        constant_value[j] = 0u;
        if (dense[j] && mode[j] == 255u) {
            if (end[j] - first[j] == 2u)
                constant_value[j] = uint(payload[first[j]])
                    | (uint(payload[first[j] + 1u]) << 8u);
            else active[j] = dense[j] = false;
        } else if (dense[j] && mode[j] == 254u) {
            if (end[j] - first[j] != 2u * PRT_INTERVAL)
                active[j] = dense[j] = false;
        } else if (entropy[j]) {
            device const uint *table = decoding
                + prt_entropy_model(mode[j]) * PRT_STATES;
            if (!prt_fast_begin(
                payload, first[j], end[j], payload_bytes, table, reader[j]))
                active[j] = dense[j] = entropy[j] = false;
        } else if (dense[j]) {
            active[j] = dense[j] = false;
        }
        if (!active[j] && local < prt_partial_leaf_width && ordinal < changed)
            atomic_store_explicit(failure, 42u, memory_order_relaxed);
    }

    uint output_fields = prt_partial_output_fields == 0u
        ? groups : prt_partial_output_fields;
    if (output_fields < groups) {
        if (lane == 0u) atomic_store_explicit(failure, 48u, memory_order_relaxed);
        return;
    }
    uint partial_first = (group.y * output_fields + group.x) * PRT_INTERVAL;
    device uint *plain_partials = reinterpret_cast<device uint *>(partials);
    if (prt_partial_stores) {
        // The host normally clears this lazy, reusable buffer.  The direct
        // specialization clears only its owned field on-GPU, permitting the
        // host-side memset to be skipped without leaving stale scans behind.
        for (uint scan = lane; scan < PRT_INTERVAL; scan += 32u)
            plain_partials[partial_first + scan] = 0u;
        threadgroup_barrier(mem_flags::mem_device);
    }
    bool any_sparse = simd_any(sparse[0] || sparse[1]);
    if (simd_any(dense[0] || dense[1])) {
        for (uint pair = 0u; pair < PRT_INTERVAL / 2u; ++pair) {
            int sum_a = 0, sum_b = 0;
            #pragma unroll
            for (uint j = 0u; j < 2u; ++j) {
                uint a = 0u, b = 0u;
                if (dense[j]) {
                    if (entropy[j]) {
                        if (!prt_fast_pair(reader[j], a, b)) {
                            atomic_store_explicit(failure, 43u, memory_order_relaxed);
                            dense[j] = false;
                        }
                    } else if (mode[j] == 254u) {
                        uint at = first[j] + 4u * pair;
                        a = uint(payload[at]) | (uint(payload[at + 1u]) << 8u);
                        b = uint(payload[at + 2u]) | (uint(payload[at + 3u]) << 8u);
                    } else {
                        a = b = constant_value[j];
                    }
                }
                sum_a += int(a) * coefficient[j];
                sum_b += int(b) * coefficient[j];
            }
            sum_a = simd_sum(sum_a);
            sum_b = simd_sum(sum_b);
            if (lane == 0u) {
                if (prt_partial_stores) {
                    plain_partials[partial_first + 2u * pair] = uint(sum_a);
                    plain_partials[partial_first + 2u * pair + 1u] = uint(sum_b);
                } else {
                    atomic_fetch_add_explicit(
                        partials + partial_first + 2u * pair, uint(sum_a), memory_order_relaxed);
                    atomic_fetch_add_explicit(
                        partials + partial_first + 2u * pair + 1u, uint(sum_b),
                        memory_order_relaxed);
                }
            }
        }
        #pragma unroll
        for (uint j = 0u; j < 2u; ++j)
            if (entropy[j] && dense[j] && !prt_fast_finished(reader[j]))
                atomic_store_explicit(failure, 44u, memory_order_relaxed);
    }
    if (prt_partial_stores && any_sparse)
        threadgroup_barrier(mem_flags::mem_device);
    #pragma unroll
    for (uint j = 0u; j < 2u; ++j) {
        if (sparse[j]) {
            if (((end[j] - first[j]) & 1u) != 0u) {
                atomic_store_explicit(failure, 45u, memory_order_relaxed);
            } else {
                uint previous = 0u;
                bool has_previous = false;
                for (uint cursor = first[j]; cursor < end[j]; cursor += 2u) {
                    uint event = uint(payload[cursor])
                        | (uint(payload[cursor + 1u]) << 8u);
                    uint position = event >> 7u;
                    if (position >= PRT_INTERVAL || (has_previous && position <= previous)) {
                        atomic_store_explicit(failure, 46u, memory_order_relaxed);
                        break;
                    }
                    uint contribution = uint(int((event & 127u) + 1u) * coefficient[j]);
                    atomic_fetch_add_explicit(
                        partials + partial_first + position, contribution,
                        memory_order_relaxed);
                    previous = position;
                    has_previous = true;
                }
            }
        }
    }
}

kernel void paired_runtime_tans_detector_finish(
    device const uint *partials [[buffer(0)]],
    device uint *output [[buffer(1)]],
    constant uint *p [[buffer(2)]],
    uint scan [[thread_position_in_grid]]) {
    uint packets = p[0], groups = p[1];
    if (scan >= packets * PRT_INTERVAL) return;
    uint packet = scan / PRT_INTERVAL;
    uint local = scan % PRT_INTERVAL;
    uint value = output[scan];
    for (uint group = 0u; group < groups; ++group)
        value += partials[(packet * groups + group) * PRT_INTERVAL + local];
    output[scan] = value;
}

// Exact bounded polar-field index. Existing leaves use packet-major layout
// ((packet * 576 + leaf) * 512 + scan). The output uses the corresponding
// 612-field stride and contains copied leaves followed by 36 exact roots.
kernel void paired_runtime_tans_polar_roots(
    device const uint *leaves [[buffer(0)]],
    device uint *fields [[buffer(1)]],
    device atomic_uint *failure [[buffer(2)]],
    constant uint *p [[buffer(3)]],
    uint job [[thread_position_in_grid]]) {
    uint packets = p[0];
    if (job >= packets * 612u * PRT_INTERVAL) return;
    uint scan = job % PRT_INTERVAL;
    uint field = (job / PRT_INTERVAL) % 612u;
    uint packet = job / (612u * PRT_INTERVAL);
    if (packet >= packets) {
        atomic_store_explicit(failure, 90u, memory_order_relaxed);
        return;
    }
    uint output_at = (packet * 612u + field) * PRT_INTERVAL + scan;
    if (field < 576u) {
        fields[output_at] = leaves[(packet * 576u + field) * PRT_INTERVAL + scan];
        return;
    }
    uint root = field - 576u;
    uint value = 0u;
    for (uint leaf = 0u; leaf < 16u; ++leaf) {
        uint source_field = root * 16u + leaf;
        value += leaves[(packet * 576u + source_field) * PRT_INTERVAL + scan];
    }
    fields[output_at] = value;
}

// Append roots to a packet-major field buffer whose leaf region was written
// directly by the leaf-width-specialized detector-partials kernel.
kernel void paired_runtime_tans_polar_roots_in_place(
    device uint *fields [[buffer(0)]],
    device atomic_uint *failure [[buffer(1)]],
    constant uint *p [[buffer(2)]],
    uint job [[thread_position_in_grid]]) {
    uint packets = p[0], leaves = p[1], field_count = p[2];
    if (leaves == 0u || leaves > 2304u || (leaves & 15u) != 0u
        || field_count != leaves + leaves / 16u || field_count > 2448u) {
        if (job == 0u) atomic_store_explicit(failure, 103u, memory_order_relaxed);
        return;
    }
    uint roots = leaves / 16u;
    if (job >= packets * roots * PRT_INTERVAL) return;
    uint scan = job % PRT_INTERVAL;
    uint root = (job / PRT_INTERVAL) % roots;
    uint packet = job / (roots * PRT_INTERVAL);
    uint value = 0u;
    for (uint offset = 0u; offset < 16u; ++offset) {
        uint leaf = root * 16u + offset;
        value += fields[(packet * field_count + leaf) * PRT_INTERVAL + scan];
    }
    uint output_field = leaves + root;
    fields[(packet * field_count + output_field) * PRT_INTERVAL + scan] = value;
}

// One job per (field, packet). A tag's low six bits are width 0...32 and bit7
// means payload begins with one UInt32 minimum followed by packed deltas.
// sizes are measured in UInt32 words and may be CPU-prefixed into offsets.
kernel void paired_runtime_tans_polar_sizes(
    device const uint *fields [[buffer(0)]],
    device uchar *tags [[buffer(1)]],
    device uint *sizes [[buffer(2)]],
    device atomic_uint *failure [[buffer(3)]],
    constant uint *p [[buffer(4)]],
    uint stream [[thread_position_in_grid]]) {
    uint packets = p[0], field_count = p[1];
    if (stream >= packets * field_count) return;
    if (field_count > 2448u) {
        atomic_store_explicit(failure, 91u, memory_order_relaxed);
        return;
    }
    uint packet = stream / field_count, field = stream - packet * field_count;
    uint first = (packet * field_count + field) * PRT_INTERVAL;
    uint lo = 0xffffffffu, hi = 0u;
    for (uint scan = 0u; scan < PRT_INTERVAL; ++scan) {
        uint value = fields[first + scan];
        lo = min(lo, value);
        hi = max(hi, value);
    }
    uint range = hi - lo;
    uint raw_width = hi == 0u ? 0u : 32u - clz(hi);
    uint delta_width = range == 0u ? 0u : 32u - clz(range);
    uint raw_words = (PRT_INTERVAL * raw_width + 31u) / 32u;
    uint delta_words = 1u + (PRT_INTERVAL * delta_width + 31u) / 32u;
    bool use_delta = delta_words < raw_words;
    tags[stream] = uchar((use_delta ? 128u : 0u)
        | (use_delta ? delta_width : raw_width));
    sizes[stream] = use_delta ? delta_words : raw_words;
}

kernel void paired_runtime_tans_polar_pack(
    device const uint *fields [[buffer(0)]],
    device const uchar *tags [[buffer(1)]],
    device const uint *offsets [[buffer(2)]],
    device uint *payload [[buffer(3)]],
    device atomic_uint *failure [[buffer(4)]],
    constant uint *p [[buffer(5)]],
    uint stream [[thread_position_in_grid]]) {
    uint packets = p[0], field_count = p[1], payload_words = p[2];
    uint streams = packets * field_count;
    if (stream >= streams) return;
    uint begin = offsets[stream], end = offsets[stream + 1u];
    uint tag = uint(tags[stream]), width = tag & 63u;
    if (field_count > 2448u || (tag & 64u) != 0u || width > 32u
        || end < begin || end > payload_words) {
        atomic_store_explicit(failure, 92u, memory_order_relaxed);
        return;
    }
    uint expected = (tag & 128u ? 1u : 0u)
        + (PRT_INTERVAL * width + 31u) / 32u;
    if (end - begin != expected) {
        atomic_store_explicit(failure, 93u, memory_order_relaxed);
        return;
    }
    uint packet = stream / field_count, field = stream - packet * field_count;
    uint first = (packet * field_count + field) * PRT_INTERVAL;
    uint at = begin, base = 0u;
    if ((tag & 128u) != 0u) {
        base = 0xffffffffu;
        for (uint scan = 0u; scan < PRT_INTERVAL; ++scan)
            base = min(base, fields[first + scan]);
        payload[at++] = base;
    }
    if (width == 0u) return;
    ulong reservoir = 0u;
    uint available = 0u;
    for (uint scan = 0u; scan < PRT_INTERVAL; ++scan) {
        reservoir |= ulong(fields[first + scan] - base) << available;
        available += width;
        if (available >= 32u) {
            if (at >= end) {
                atomic_store_explicit(failure, 94u, memory_order_relaxed);
                return;
            }
            payload[at++] = uint(reservoir);
            reservoir >>= 32u;
            available -= 32u;
        }
    }
    if (available != 0u) {
        if (at >= end) {
            atomic_store_explicit(failure, 94u, memory_order_relaxed);
            return;
        }
        payload[at++] = uint(reservoir);
    }
    if (at != end) atomic_store_explicit(failure, 95u, memory_order_relaxed);
}

// One 128-thread group owns 128 consecutive scans within a 512-scan packet.
// The caller supplies dynamic threadgroup memory of selected_count*16 bytes.
kernel void paired_runtime_tans_polar_query(
    device const uint *payload [[buffer(0)]],
    device const uint *offsets [[buffer(1)]],
    device const uchar *tags [[buffer(2)]],
    device const uint *selected [[buffer(3)]],
    device const int *coefficients [[buffer(4)]],
    device uint *output [[buffer(5)]],
    device atomic_uint *failure [[buffer(6)]],
    constant uint *p [[buffer(7)]],
    threadgroup uint *shared [[threadgroup(0)]],
    uint group [[threadgroup_position_in_grid]],
    uint lane [[thread_index_in_threadgroup]]) {
    uint packets = p[0], field_count = p[1], selected_count = p[2];
    uint payload_words = p[3], output_first = p[4];
    if (selected_count > field_count || field_count > 2448u) {
        if (lane == 0u) atomic_store_explicit(failure, 96u, memory_order_relaxed);
        return;
    }
    uint packet = group / 4u, quarter = group & 3u;
    if (packet >= packets) return;
    threadgroup uint *word_first = shared;
    threadgroup uint *bases = shared + selected_count;
    threadgroup uint *widths = shared + 2u * selected_count;
    threadgroup int *coefs = reinterpret_cast<threadgroup int *>(
        shared + 3u * selected_count);
    for (uint ordinal = lane; ordinal < selected_count; ordinal += 128u) {
        uint field = selected[ordinal];
        if (field >= field_count) {
            atomic_store_explicit(failure, 97u, memory_order_relaxed);
            field = 0u;
        }
        uint stream = packet * field_count + field;
        uint begin = offsets[stream], end = offsets[stream + 1u];
        uint tag = uint(tags[stream]), width = tag & 63u;
        uint base = 0u;
        if ((tag & 64u) != 0u || width > 32u || end < begin || end > payload_words) {
            atomic_store_explicit(failure, 98u, memory_order_relaxed);
            begin = end = 0u;
            width = 0u;
        } else if ((tag & 128u) != 0u) {
            if (begin >= end) {
                atomic_store_explicit(failure, 99u, memory_order_relaxed);
                begin = end = 0u;
                width = 0u;
            } else base = payload[begin++];
        }
        uint expected_words = (PRT_INTERVAL * width + 31u) / 32u;
        if (end - begin != expected_words) {
            atomic_store_explicit(failure, 100u, memory_order_relaxed);
            begin = end = 0u;
            width = 0u;
            base = 0u;
        }
        word_first[ordinal] = begin;
        bases[ordinal] = base;
        widths[ordinal] = width;
        coefs[ordinal] = coefficients[ordinal];
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    uint local = quarter * 128u + lane;
    uint value = output[output_first + packet * PRT_INTERVAL + local];
    for (uint ordinal = 0u; ordinal < selected_count; ++ordinal) {
        uint width = widths[ordinal], field_value = bases[ordinal];
        if (width != 0u) {
            uint bit = local * width;
            uint at = word_first[ordinal] + (bit >> 5u);
            uint shift = bit & 31u;
            if (at >= payload_words) {
                atomic_store_explicit(failure, 101u, memory_order_relaxed);
                continue;
            }
            ulong words = ulong(payload[at]);
            if (shift + width > 32u) {
                if (at + 1u >= payload_words) {
                    atomic_store_explicit(failure, 102u, memory_order_relaxed);
                    continue;
                }
                words |= ulong(payload[at + 1u]) << 32u;
            }
            uint extracted = uint(words >> shift);
            field_value += width == 32u
                ? extracted : extracted & ((1u << width) - 1u);
        }
        value += uint(coefs[ordinal]) * field_value;
    }
    output[output_first + packet * PRT_INTERVAL + local] = value;
}
