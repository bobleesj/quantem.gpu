import Foundation
import Metal
@_spi(PairedRuntimeTANSPrototype) import Metal4DSTEMKernels

/// Exact packed polar-field accelerator for paired-runtime detector deltas.
final class MetalPairedRuntimeTANSPolarIndex {
  private static let buildLock = NSLock()
  private static let scansPerPacket = 512

  private let device: MTLDevice
  private let packets: Int
  let leafPixels: Int
  let layoutKind: String
  private let leaves: Int
  private let fields: Int
  private let packedPayload: MTLBuffer
  private let packedOffsets: MTLBuffer
  private let packedTags: MTLBuffer
  private let queryPipeline: MTLComputePipelineState

  let residentBytes: UInt64
  let buildMilliseconds: Double

  struct PreparedInputs {
    struct Batch {
      let selected: MTLBuffer
      let coefficients: MTLBuffer
      let count: Int
    }
    let batches: [Batch]
    var byteCount: Int {
      batches.reduce(0) { $0 + $1.selected.length + $1.coefficients.length }
    }
  }

  init(
    device: MTLDevice, library: MTLLibrary, queue: MTLCommandQueue,
    payload: MTLBuffer, offsets: MTLBuffer, modes: MTLBuffer, decoding: MTLBuffer,
    validPixels: [UInt8], packets: Int = 512, leafPixels: Int = 64,
    layoutKind: String = "polar", compactOffsetsEnabled: Bool = false
  ) throws {
    let started = CFAbsoluteTimeGetCurrent()
    Self.buildLock.lock()
    defer { Self.buildLock.unlock() }
    guard packets > 0, [16, 32, 64].contains(leafPixels), validPixels.count == 192 * 192,
      validPixels.allSatisfy({ $0 == 0 || $0 == 1 }),
      payload.device.registryID == device.registryID,
      offsets.device.registryID == device.registryID,
      modes.device.registryID == device.registryID,
      decoding.device.registryID == device.registryID
    else { throw Self.invalid("Polar-index inputs do not match the paired-runtime ABI") }
    self.device = device
    self.packets = packets
    self.leafPixels = leafPixels
    self.layoutKind = layoutKind
    let leaves = 192 * 192 / leafPixels
    let fields = leaves + leaves / 16
    self.leaves = leaves
    self.fields = fields
    let retainedCap = (leafPixels == 64 ? 256 : leafPixels == 32 ? 384 : 512) * 1024 * 1024

    let partialConstants = MTLFunctionConstantValues()
    var leafWidth = UInt32(leafPixels)
    var fieldStride = UInt32(fields)
    var compactOffsets = compactOffsetsEnabled
    partialConstants.setConstantValue(&leafWidth, type: .uint, index: 5)
    partialConstants.setConstantValue(&fieldStride, type: .uint, index: 6)
    partialConstants.setConstantValue(
      &compactOffsets, type: .bool,
      index: Metal4DSTEMKernels.pairedRuntimeTANSCompactOffsetsFunctionConstantIndex)
    let partialFunction = try library.makeFunction(
      name: "paired_runtime_tans_detector_partials", constantValues: partialConstants)
    let partialsPipeline = try device.makeComputePipelineState(function: partialFunction)
    let rootsPipeline = try Self.pipeline(
      library: library, device: device, name: "paired_runtime_tans_polar_roots_in_place")
    let sizesPipeline = try Self.pipeline(
      library: library, device: device, name: "paired_runtime_tans_polar_sizes")
    let packPipeline = try Self.pipeline(
      library: library, device: device, name: "paired_runtime_tans_polar_pack")
    queryPipeline = try Self.pipeline(
      library: library, device: device, name: "paired_runtime_tans_polar_query")

    let fieldBytes = try Self.byteProduct([packets, fields, Self.scansPerPacket, 4])
    let streamCount = try Self.byteProduct([packets, fields])
    let streamMetadataBytes = try Self.byteProduct([streamCount, 5])
    let selectionBytes = try Self.byteProduct([validPixels.count, 8])
    let metadataBytes = streamMetadataBytes + selectionBytes + 4
    let transientBytes = UInt64(fieldBytes) + UInt64(metadataBytes)
    let allocated = UInt64(device.currentAllocatedSize)
    guard allocated <= device.recommendedMaxWorkingSetSize,
      transientBytes <= device.recommendedMaxWorkingSetSize - allocated
    else {
      throw Self.invalid(
        "Polar-index construction needs \(transientBytes) additional bytes; release residents")
    }
    let fieldBuffer = try Self.buffer(
      device: device, bytes: fieldBytes, options: .storageModePrivate,
      label: "paired-runtime polar fields")
    let sizes = try Self.buffer(
      device: device, bytes: streamCount * 4, options: .storageModeShared,
      label: "paired-runtime polar sizes")
    let tags = try Self.buffer(
      device: device, bytes: streamCount, options: .storageModePrivate,
      label: "paired-runtime polar tags")
    let failure = try Self.buffer(
      device: device, bytes: 4, options: .storageModeShared,
      label: "paired-runtime polar failure")

    guard let layout = PairedRuntimeTANSPolarPlan.indexLayout(
      leafPixels: leafPixels, layoutKind: layoutKind) else {
      throw Self.invalid("Polar-index leaf width is unsupported")
    }
    let permutation = layout.permutation
    guard permutation.count == validPixels.count, permutation.allSatisfy({ $0 >= 0 }) else {
      throw Self.invalid("Polar-index permutation is incomplete")
    }
    let selected = permutation.map { UInt32($0) }
    let coefficients = permutation.map { Int32(validPixels[Int($0)]) }
    let selectedBuffer = try Self.upload(
      selected, device: device, label: "paired-runtime polar permutation")
    let coefficientBuffer = try Self.upload(
      coefficients, device: device, label: "paired-runtime polar validity")
    memset(failure.contents(), 0, 4)
    guard let fieldCommand = queue.makeCommandBuffer(),
      let clear = fieldCommand.makeBlitCommandEncoder()
    else { throw Self.invalid("Metal could not begin polar-field construction") }
    clear.fill(buffer: fieldBuffer, range: 0..<fieldBuffer.length, value: 0)
    clear.endEncoding()
    guard let fieldEncoder = fieldCommand.makeComputeCommandEncoder() else {
      throw Self.invalid("Metal could not encode polar-field construction")
    }
    var partialParameters: [UInt32] = [
      UInt32(validPixels.count), UInt32(packets), UInt32(selected.count), UInt32(leaves),
      UInt32(payload.length),
    ]
    fieldEncoder.setComputePipelineState(partialsPipeline)
    for (index, buffer) in [
      payload, offsets, modes, decoding, selectedBuffer, coefficientBuffer,
      fieldBuffer, failure,
    ].enumerated() {
      fieldEncoder.setBuffer(buffer, offset: 0, index: index)
    }
    fieldEncoder.setBytes(&partialParameters, length: partialParameters.count * 4, index: 8)
    fieldEncoder.dispatchThreadgroups(
      MTLSize(width: leaves, height: packets, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 32, height: 1, depth: 1))
    var rootParameters: [UInt32] = [UInt32(packets), UInt32(leaves), UInt32(fields)]
    fieldEncoder.setComputePipelineState(rootsPipeline)
    fieldEncoder.setBuffer(fieldBuffer, offset: 0, index: 0)
    fieldEncoder.setBuffer(failure, offset: 0, index: 1)
    fieldEncoder.setBytes(&rootParameters, length: rootParameters.count * 4, index: 2)
    fieldEncoder.dispatchThreads(
      MTLSize(width: packets * (leaves / 16) * Self.scansPerPacket, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 256, height: 1, depth: 1))
    fieldEncoder.endEncoding()
    try Self.finish(fieldCommand, failure: failure, operation: "polar fields")

    memset(failure.contents(), 0, 4)
    guard let sizeCommand = queue.makeCommandBuffer(),
      let sizeEncoder = sizeCommand.makeComputeCommandEncoder()
    else { throw Self.invalid("Metal could not encode polar-field sizes") }
    var sizeParameters: [UInt32] = [UInt32(packets), UInt32(fields)]
    sizeEncoder.setComputePipelineState(sizesPipeline)
    sizeEncoder.setBuffer(fieldBuffer, offset: 0, index: 0)
    sizeEncoder.setBuffer(tags, offset: 0, index: 1)
    sizeEncoder.setBuffer(sizes, offset: 0, index: 2)
    sizeEncoder.setBuffer(failure, offset: 0, index: 3)
    sizeEncoder.setBytes(&sizeParameters, length: sizeParameters.count * 4, index: 4)
    sizeEncoder.dispatchThreads(
      MTLSize(width: streamCount, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
    sizeEncoder.endEncoding()
    try Self.finish(sizeCommand, failure: failure, operation: "polar sizes")

    let sizeValues = sizes.contents().assumingMemoryBound(to: UInt32.self)
    var prefix = [UInt32](repeating: 0, count: streamCount + 1)
    var words = UInt64(0)
    for stream in 0..<streamCount {
      words += UInt64(sizeValues[stream])
      guard words <= UInt64(UInt32.max) else {
        throw Self.invalid("Polar-index payload exceeds its UInt32 offset ABI")
      }
      prefix[stream + 1] = UInt32(words)
    }
    let retained = words * 4 + UInt64(prefix.count * 4 + streamCount)
    guard retained <= UInt64(retainedCap) else {
      throw Self.invalid(
        "Polar index needs \(retained) retained bytes, above its \(retainedCap)-byte prototype cap")
    }
    let allocatedForPacking = UInt64(device.currentAllocatedSize)
    guard allocatedForPacking <= device.recommendedMaxWorkingSetSize,
      retained <= device.recommendedMaxWorkingSetSize - allocatedForPacking
    else {
      throw Self.invalid(
        "Polar-index packing needs \(retained) more bytes; release other residents")
    }
    let packedPayload = try Self.buffer(
      device: device, bytes: max(4, Int(words * 4)), options: .storageModePrivate,
      label: "paired-runtime packed polar payload")
    let packedOffsets = try Self.privateUpload(
      prefix, device: device, queue: queue, label: "paired-runtime polar offsets")

    memset(failure.contents(), 0, 4)
    guard let packCommand = queue.makeCommandBuffer(),
      let packEncoder = packCommand.makeComputeCommandEncoder()
    else { throw Self.invalid("Metal could not encode polar-field packing") }
    var packParameters: [UInt32] = [
      UInt32(packets), UInt32(fields), UInt32(words),
    ]
    packEncoder.setComputePipelineState(packPipeline)
    for (index, buffer) in [fieldBuffer, tags, packedOffsets, packedPayload, failure].enumerated() {
      packEncoder.setBuffer(buffer, offset: 0, index: index)
    }
    packEncoder.setBytes(&packParameters, length: packParameters.count * 4, index: 5)
    packEncoder.dispatchThreads(
      MTLSize(width: streamCount, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
    packEncoder.endEncoding()
    try Self.finish(packCommand, failure: failure, operation: "polar packing")

    self.packedPayload = packedPayload
    self.packedOffsets = packedOffsets
    packedTags = tags
    residentBytes = UInt64(packedPayload.length + packedOffsets.length + tags.length)
    buildMilliseconds = (CFAbsoluteTimeGetCurrent() - started) * 1_000
  }

  /// Encode the indexed part of one exact plan without committing or synchronizing.
  func encode(
    plan: PairedRuntimeTANSPolarPlan, output: MTLBuffer, failure: MTLBuffer,
    command: MTLCommandBuffer,
    profiler: PairedRuntimeDetectorProfiler.Session? = nil
  ) throws {
    guard command.retainedReferences,
      output.device.registryID == device.registryID,
      failure.device.registryID == device.registryID
    else { throw Self.invalid("Polar query requires retaining commands and same-device buffers") }
    let inputs = try prepareInputs(plan: plan)
    try encode(inputs: inputs, output: output, failure: failure,
      command: command, profiler: profiler)
  }

  /// Upload immutable query batches once for repeated diagnostic submissions.
  func prepareInputs(plan: PairedRuntimeTANSPolarPlan) throws -> PreparedInputs {
    guard plan.usedIndex, plan.layoutKind == layoutKind,
      plan.leafPixelCount == leafPixels,
      plan.selectedFields.count == plan.fieldCoefficients.count,
      plan.selectedFields.allSatisfy({ Int($0) < fields })
    else { throw Self.invalid("Polar query requires one valid coefficient per selected field") }
    guard !plan.selectedFields.isEmpty else { return PreparedInputs(batches: []) }
    let batchCapacity = min(1_024, device.maxThreadgroupMemoryLength / 16)
    guard batchCapacity > 0 else {
      throw Self.invalid("Polar queries need at least 16 bytes of threadgroup memory")
    }
    var first = 0
    var batches: [PreparedInputs.Batch] = []
    while first < plan.selectedFields.count {
      let end = min(plan.selectedFields.count, first + batchCapacity)
      let batchFields = Array(plan.selectedFields[first..<end])
      let batchCoefficients = Array(plan.fieldCoefficients[first..<end])
      let selected = try Self.upload(
        batchFields, device: device, label: "paired-runtime selected polar fields")
      let coefficients = try Self.upload(
        batchCoefficients, device: device, label: "paired-runtime polar coefficients")
      batches.append(.init(selected: selected, coefficients: coefficients,
        count: batchFields.count))
      first = end
    }
    return PreparedInputs(batches: batches)
  }

  /// Encode prepared batches without allocating query input buffers.
  func encode(
    inputs: PreparedInputs, output: MTLBuffer, failure: MTLBuffer,
    command: MTLCommandBuffer,
    profiler: PairedRuntimeDetectorProfiler.Session? = nil
  ) throws {
    guard command.retainedReferences,
      output.device.registryID == device.registryID,
      failure.device.registryID == device.registryID
    else { throw Self.invalid("Polar query requires retaining commands and same-device buffers") }
    for batch in inputs.batches {
      guard let encoder = profiler?.makeComputeEncoder(
        commandBuffer: command, stage: "polar")
        ?? command.makeComputeCommandEncoder() else {
        throw Self.invalid("Metal could not encode the polar query")
      }
      var parameters: [UInt32] = [
        UInt32(packets), UInt32(fields), UInt32(batch.count),
        UInt32(packedPayload.length / 4), 0,
      ]
      encoder.setComputePipelineState(queryPipeline)
      for (index, buffer) in [
        packedPayload, packedOffsets, packedTags, batch.selected, batch.coefficients, output, failure,
      ].enumerated() {
        encoder.setBuffer(buffer, offset: 0, index: index)
      }
      encoder.setBytes(&parameters, length: parameters.count * 4, index: 7)
      encoder.setThreadgroupMemoryLength(batch.count * 16, index: 0)
      encoder.dispatchThreadgroups(
        MTLSize(width: packets * 4, height: 1, depth: 1),
        threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
      encoder.endEncoding()
    }
    // A retaining command buffer owns the bound buffers through completion.
  }

  private static func pipeline(
    library: MTLLibrary, device: MTLDevice, name: String
  ) throws -> MTLComputePipelineState {
    let constants = MTLFunctionConstantValues()
    let function = try library.makeFunction(name: name, constantValues: constants)
    return try device.makeComputePipelineState(function: function)
  }

  private static func finish(
    _ command: MTLCommandBuffer, failure: MTLBuffer, operation: String
  ) throws {
    command.commit()
    command.waitUntilCompleted()
    let code = failure.contents().load(as: UInt32.self)
    guard command.status == .completed, command.error == nil, code == 0 else {
      throw invalid(
        "Paired-runtime \(operation) failed with code \(code): "
          + (command.error?.localizedDescription ?? "invalid field index"))
    }
  }

  private static func upload<T>(
    _ values: [T], device: MTLDevice, label: String
  ) throws -> MTLBuffer {
    let result = values.withUnsafeBytes {
      device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared)
    }
    guard let result else { throw invalid("Metal could not allocate \(label)") }
    result.label = label
    return result
  }

  private static func privateUpload<T>(
    _ values: [T], device: MTLDevice, queue: MTLCommandQueue, label: String
  ) throws -> MTLBuffer {
    let staging = try upload(values, device: device, label: label + " staging")
    let result = try buffer(
      device: device, bytes: staging.length, options: .storageModePrivate, label: label)
    guard let command = queue.makeCommandBuffer(), let blit = command.makeBlitCommandEncoder()
    else { throw invalid("Metal could not upload \(label)") }
    blit.copy(from: staging, sourceOffset: 0, to: result, destinationOffset: 0,
      size: staging.length)
    blit.endEncoding()
    command.commit()
    command.waitUntilCompleted()
    guard command.status == .completed, command.error == nil else {
      throw invalid("Metal could not complete \(label) upload")
    }
    return result
  }

  private static func buffer(
    device: MTLDevice, bytes: Int, options: MTLResourceOptions, label: String
  ) throws -> MTLBuffer {
    guard bytes > 0, bytes <= device.maxBufferLength,
      let result = device.makeBuffer(length: bytes, options: options)
    else { throw invalid("Metal could not allocate \(label) (\(bytes) bytes)") }
    result.label = label
    return result
  }

  private static func byteProduct(_ factors: [Int]) throws -> Int {
    var result = 1
    for factor in factors {
      let next = result.multipliedReportingOverflow(by: factor)
      guard factor >= 0, !next.overflow else { throw invalid("Polar-index size overflow") }
      result = next.partialValue
    }
    return result
  }

  private static func invalid(_ message: String) -> Metal4DSTEMStreamingIOError {
    .invalidRequest(message)
  }
}
