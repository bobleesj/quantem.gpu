import Foundation
import Metal
@_spi(PairedRuntimeTANSPrototype) import Metal4DSTEMKernels
import Native4DSTEMIO

/// Exact original-HDF5 resident backed by the paired runtime tANS ABI.
public final class MetalPairedRuntimeTANSResidentSource: @unchecked Sendable {
  public let shape: [Int]
  public let logicalDtype: Metal4DSTEMIntegerDType
  public let sourceIdentitySHA256: String
  @_spi(PairedRuntimeTANSPrototype) public let compactOffsetsEnabled: Bool
  public private(set) var loadMetrics: MetalPairedRuntimeTANSBuildMetrics
  public let dpcMoments: MetalCompactH5ExactDPCMoments
  private var released = false
  public var isReleased: Bool {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedReleased
  }

  private var payload: MTLBuffer!
  private var offsets: MTLBuffer!
  private var modes: MTLBuffer!
  private var decodingTable: MTLBuffer!
  private var macroDecodingTable: MTLBuffer?
  private var polarIndex: MetalPairedRuntimeTANSPolarIndex?
  private struct DiagnosticScratch {
    let jointPlanEnabled: Bool
    let previous: [UInt8]
    let target: [UInt8]
    let plan: PairedRuntimeTANSPolarPlan
    let output: MTLBuffer
    let status: MTLBuffer
    let selected: MTLBuffer
    let coefficients: MTLBuffer
    let indexInputs: MetalPairedRuntimeTANSPolarIndex.PreparedInputs?
    var byteCount: Int {
      output.length + status.length + selected.length + coefficients.length
        + (indexInputs?.byteCount ?? 0)
    }
  }
  private var diagnosticScratch: DiagnosticScratch?
  private let stateLock = NSLock()
  private let metadataLock = NSLock()
  private var cachedReleased = false
  private var cachedResidentBytes: UInt64 = 0
  private var cachedPolarFieldCount = 0
  private var cachedPolarResidualCount = 0
  private var cachedHistoryHit = false
  private var cachedHistoryBase = false
  private var cachedUpdateProfile: [String: Double] = [:]
  private var cachedPolarIndexBytes: UInt64 = 0
  private var cachedPolarIndexBuildMilliseconds: Double = 0
  private var polarFieldCount = 0
  private var polarResidualCount = 0
  @_spi(PairedRuntimeTANSPrototype) public var lastPolarFieldCount: Int {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedPolarFieldCount
  }
  @_spi(PairedRuntimeTANSPrototype) public var lastPolarResidualCount: Int {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedPolarResidualCount
  }
  @_spi(PairedRuntimeTANSPrototype) public var polarIndexBytes: UInt64 {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedPolarIndexBytes
  }
  @_spi(PairedRuntimeTANSPrototype) public var polarIndexBuildMilliseconds: Double {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedPolarIndexBuildMilliseconds
  }
  @_spi(PairedRuntimeTANSPrototype) public var compactOffsetBytes: Int {
    compactOffsetsEnabled ? (offsets?.length ?? 0) : 0
  }
  @_spi(PairedRuntimeTANSPrototype) public var lastHistoryHit: Bool {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedHistoryHit
  }
  @_spi(PairedRuntimeTANSPrototype) public var lastHistoryBase: Bool {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedHistoryBase
  }
  @_spi(PairedRuntimeTANSPrototype) public var lastUpdateProfile: [String: Double] {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedUpdateProfile
  }
  private let queue: MTLCommandQueue
  private let detectorProfiler: PairedRuntimeDetectorProfiler?
  private let selectedDPPipeline: MTLComputePipelineState
  private let detectorPipeline: MTLComputePipelineState
  private let detectorPacketOwner2Pipeline: MTLComputePipelineState
  private let detectorBranchlessPopPipeline: MTLComputePipelineState?
  private let detectorRefillPipelines: [Int: MTLComputePipelineState]
  private let detectorPhasedReadersPipeline: MTLComputePipelineState?
  private let detectorPairUnrollPipelines: [Int: MTLComputePipelineState]
  private let detectorDecodeChecksumPipeline: MTLComputePipelineState?
  private let detectorLazyRefillPipeline: MTLComputePipelineState?
  private let detectorTrustedTablePipeline: MTLComputePipelineState?
  private let detectorPacketOwner4Pipeline: MTLComputePipelineState
  private let detectorSplitPipelines: [Int: MTLComputePipelineState]
  private let detectorReuseWordPipeline: MTLComputePipelineState?
  private let detectorRegisterSumsPipeline: MTLComputePipelineState?
  private let detectorPlainSumsPipeline: MTLComputePipelineState?
  private let detectorMacroPipeline: MTLComputePipelineState?
  private let detectorReader32Pipeline: MTLComputePipelineState?
  private let detectorCooperativePipeline: MTLComputePipelineState?
  private let detectorSparseScatterPipeline: MTLComputePipelineState?
  private let detectorDenseCompactionPipeline: MTLComputePipelineState?
  private let detectorPartialsPipeline: MTLComputePipelineState
  private let detectorPartialStoresPipeline: MTLComputePipelineState?
  private let detectorFinishPipeline: MTLComputePipelineState
  private var failure: MTLBuffer!
  private var diffraction: MTLBuffer!
  private var detectorProduct: MTLBuffer!
  private let historyEnabled: Bool
  private var historyProduct: MTLBuffer?
  private var historyMask: [UInt8]?
  private var historyValid = false
  private var historyPolarFieldCount = 0
  private var historyPolarResidualCount = 0
  private var detectorPartials: MTLBuffer?
  private var detectorMask: [UInt8]
  private let validPixels: [UInt8]

  public var residentBytes: UInt64 {
    metadataLock.lock()
    defer { metadataLock.unlock() }
    return cachedResidentBytes
  }

  /// Binary detector-validity mask used by derived products; raw DPs stay untouched.
  public var detectorValidityMask: [UInt8] {
    validPixels
  }

  /// Decode and encode one complete native acquisition directly into paired tANS.
  public static func supports(source: Native4DSTEMIndexedSource) -> Bool {
    source.dataset.scanRows == PairedRuntimeTANSRecordABI.scanRows
      && source.dataset.scanCols == PairedRuntimeTANSRecordABI.scanColumns
      && source.dataset.detectorRows == PairedRuntimeTANSRecordABI.detectorRows
      && source.dataset.detectorCols == PairedRuntimeTANSRecordABI.detectorColumns
      && source.logicalFrameCount
        == PairedRuntimeTANSRecordABI.recordScans
        * PairedRuntimeTANSRecordABI.recordsPerAcquisition
      && (source.sourceBytesPerValue == 1 || source.sourceBytesPerValue == 2)
  }

  /// Decode and encode one complete native acquisition directly into paired tANS.
  public static func load(
    source: Native4DSTEMIndexedSource, device: MTLDevice,
    maximumAdditionalBytes: UInt64? = nil,
    shouldCancel: () -> Bool = { false },
    progress: (Int, Int) -> Void = { _, _ in }
  ) throws -> MetalPairedRuntimeTANSResidentSource {
    let started = CFAbsoluteTimeGetCurrent()
    let result = try MetalPairedRuntimeTANSHDF5Builder.build(
      source: source, device: device, maximumAdditionalBytes: maximumAdditionalBytes,
      shouldCancel: shouldCancel, progress: progress)
    return try MetalPairedRuntimeTANSResidentSource(
      source: source, provider: result.provider, dpcMoments: result.dpcMoments,
      metrics: result.metrics,
      loadStarted: started, device: device)
  }

  private init(
    source: Native4DSTEMIndexedSource, provider: PairedRuntimeTANSRecordProvider,
    dpcMoments: MetalCompactH5ExactDPCMoments,
    metrics: MetalPairedRuntimeTANSBuildMetrics, loadStarted: Double, device: MTLDevice
  ) throws {
    guard let identity = source.dataset.sourceIdentitySHA256,
      let queue = device.makeCommandQueue()
    else { throw Self.invalid("Paired-runtime resident initialization failed") }
    let library = try Metal4DSTEMKernels.makePairedRuntimeTANSLibrary(device: device)
    let compactOffsetSetting = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_COMPACT_OFFSETS"] == "1"
    compactOffsetsEnabled = compactOffsetSetting
    let makeFunctionConstants: () -> MTLFunctionConstantValues = {
      let values = MTLFunctionConstantValues()
      var enabled = compactOffsetSetting
      values.setConstantValue(
        &enabled, type: .bool,
        index: Metal4DSTEMKernels.pairedRuntimeTANSCompactOffsetsFunctionConstantIndex)
      return values
    }
    let defaults = makeFunctionConstants()
    let selectedDP = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSSelectedDPFunction,
      constantValues: defaults)
    let detector = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwnerFunction,
      constantValues: defaults)
    let detectorPartials = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPartialsFunction,
      constantValues: defaults)
    let detectorFinish = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorFinishFunction,
      constantValues: defaults)
    self.queue = queue
    detectorProfiler = PairedRuntimeDetectorProfiler.makeIfRequested(device: device)
    selectedDPPipeline = try device.makeComputePipelineState(function: selectedDP)
    detectorPipeline = try device.makeComputePipelineState(function: detector)
    var twoStreams = UInt32(2)
    let twoConstants = makeFunctionConstants()
    twoConstants.setConstantValue(&twoStreams, type: .uint, index: 0)
    let detectorPacketOwner2 = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
      constantValues: twoConstants)
    detectorPacketOwner2Pipeline = try device.makeComputePipelineState(function: detectorPacketOwner2)
    if ProcessInfo.processInfo.environment["QGPU_PREPARE_BRANCHLESS_POP"] == "1" {
      let constants = makeFunctionConstants()
      var enabled = true
      constants.setConstantValue(&twoStreams, type: .uint, index: 0)
      constants.setConstantValue(&enabled, type: .bool, index: 16)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorBranchlessPopPipeline = try device.makeComputePipelineState(function: function)
    } else { detectorBranchlessPopPipeline = nil }
    var refillPipelines: [Int: MTLComputePipelineState] = [:]
    if ProcessInfo.processInfo.environment["QGPU_PREPARE_REFILL_THRESHOLDS"] == "1" {
      for threshold in [16, 24] {
        let constants = makeFunctionConstants()
        var refillThreshold = UInt32(threshold)
        constants.setConstantValue(&twoStreams, type: .uint, index: 0)
        constants.setConstantValue(&refillThreshold, type: .uint, index: 17)
        let function = try library.makeFunction(
          name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
          constantValues: constants)
        refillPipelines[threshold] = try device.makeComputePipelineState(function: function)
      }
    }
    detectorRefillPipelines = refillPipelines
    if ProcessInfo.processInfo.environment["QGPU_PREPARE_PHASED_READERS"] == "1" {
      let constants = makeFunctionConstants()
      var enabled = true
      constants.setConstantValue(&twoStreams, type: .uint, index: 0)
      constants.setConstantValue(&enabled, type: .bool, index: 18)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorPhasedReadersPipeline = try device.makeComputePipelineState(function: function)
    } else { detectorPhasedReadersPipeline = nil }
    var pairUnrollPipelines: [Int: MTLComputePipelineState] = [:]
    if ProcessInfo.processInfo.environment["QGPU_PREPARE_PAIR_UNROLL"] == "1" {
      for factor in [2, 4, 8] {
        let constants = makeFunctionConstants()
        var pairUnroll = UInt32(factor)
        constants.setConstantValue(&twoStreams, type: .uint, index: 0)
        constants.setConstantValue(&pairUnroll, type: .uint, index: 19)
        let function = try library.makeFunction(
          name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
          constantValues: constants)
        pairUnrollPipelines[factor] = try device.makeComputePipelineState(function: function)
      }
    }
    detectorPairUnrollPipelines = pairUnrollPipelines
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_DECODE_CHECKSUM"] == "1" {
      var checksum = true
      let checksumConstants = makeFunctionConstants()
      checksumConstants.setConstantValue(&twoStreams, type: .uint, index: 0)
      checksumConstants.setConstantValue(
        &checksum, type: .bool, index: 14) // FC14: diagnostic decode checksum
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: checksumConstants)
      detectorDecodeChecksumPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorDecodeChecksumPipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_LAZY_REFILL"] == "1" {
      var lazyRefill = true
      let constants = makeFunctionConstants()
      constants.setConstantValue(&twoStreams, type: .uint, index: 0)
      constants.setConstantValue(&lazyRefill, type: .bool, index: 15)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorLazyRefillPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorLazyRefillPipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_TRUSTED_TABLE"] == "1" {
      // The provider is an internal builder product whose table is uploaded
      // from this deterministic factory; prove every transition before using
      // the FC13 fast path. Arbitrary length-valid tables are not trusted.
      try Self.validateTrustedTable(
        provider: provider, queue: queue, device: device)
      var trusted = true
      let constants = makeFunctionConstants()
      constants.setConstantValue(&twoStreams, type: .uint, index: 0)
      constants.setConstantValue(&trusted, type: .bool, index: 13)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorTrustedTablePipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorTrustedTablePipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_REUSE_WORD"] == "1" {
      let constants = makeFunctionConstants()
      var streams: UInt32 = 2
      var enabled = true
      constants.setConstantValue(&streams, type: .uint, index: 0)
      constants.setConstantValue(&enabled, type: .bool, index: 10)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorReuseWordPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorReuseWordPipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_REGISTER_SUMS"] == "1" {
      let constants = makeFunctionConstants()
      var streams: UInt32 = 2
      var enabled = true
      constants.setConstantValue(&streams, type: .uint, index: 0)
      constants.setConstantValue(&enabled, type: .bool, index: 11)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorRegisterSumsPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorRegisterSumsPipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_PLAIN_SUMS"] == "1" {
      let constants = makeFunctionConstants()
      var streams: UInt32 = 2
      var enabled = true
      constants.setConstantValue(&streams, type: .uint, index: 0)
      constants.setConstantValue(&enabled, type: .bool, index: 12)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: constants)
      detectorPlainSumsPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorPlainSumsPipeline = nil
    }
    var splitPipelines: [Int: MTLComputePipelineState] = [:]
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_PACKET_SPLITS"] == "1" {
      for count in [2, 4, 8] {
        var split = UInt32(count)
        let constants = makeFunctionConstants()
        constants.setConstantValue(&twoStreams, type: .uint, index: 0)
        constants.setConstantValue(&split, type: .uint, index: 9)
        let function = try library.makeFunction(
          name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
          constantValues: constants)
        splitPipelines[count] = try device.makeComputePipelineState(function: function)
      }
    }
    detectorSplitPipelines = splitPipelines
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_READER32"] == "1" {
      var reader32Enabled = true
      let reader32Constants = makeFunctionConstants()
      reader32Constants.setConstantValue(&twoStreams, type: .uint, index: 0)
      reader32Constants.setConstantValue(&reader32Enabled, type: .bool, index: 3)
      let detectorReader32 = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: reader32Constants)
      detectorReader32Pipeline = try device.makeComputePipelineState(function: detectorReader32)
    } else {
      detectorReader32Pipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_COOPERATIVE"] == "1" {
      let cooperativeConstants = makeFunctionConstants()
      let detectorCooperative = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorCooperativeFunction,
        constantValues: cooperativeConstants)
      detectorCooperativePipeline = try device.makeComputePipelineState(
        function: detectorCooperative)
    } else {
      detectorCooperativePipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_MACRO"] == "1" {
      var macroEnabled = true
      let macroConstants = makeFunctionConstants()
      macroConstants.setConstantValue(&twoStreams, type: .uint, index: 0)
      macroConstants.setConstantValue(&macroEnabled, type: .bool, index: 2)
      let detectorMacro = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
        constantValues: macroConstants)
      detectorMacroPipeline = try device.makeComputePipelineState(function: detectorMacro)
      let ordinary = try PairedRuntimeTANSTables.build().packedDecoding
      let interleaved = try PairedRuntimeTANSMacroTable.build(decoding: ordinary)
      macroDecodingTable = try Self.upload(
        interleaved, device: device, label: "paired-runtime macro decoding")
    } else {
      detectorMacroPipeline = nil
      macroDecodingTable = nil
    }
    var fourStreams = UInt32(4)
    let fourConstants = makeFunctionConstants()
    fourConstants.setConstantValue(&fourStreams, type: .uint, index: 0)
    let detectorPacketOwner4 = try library.makeFunction(
      name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPacketOwner2Function,
      constantValues: fourConstants)
    detectorPacketOwner4Pipeline = try device.makeComputePipelineState(function: detectorPacketOwner4)
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_SPARSE_SPLIT"] == "1" {
      let detectorSparseScatter = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorSparseScatterFunction,
        constantValues: makeFunctionConstants())
      detectorSparseScatterPipeline = try device.makeComputePipelineState(
        function: detectorSparseScatter)
    } else {
      detectorSparseScatterPipeline = nil
    }
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_DENSE_COMPACTION"] == "1" {
      var plainScratch =
        ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PLAIN_SCRATCH"] == "1"
      let denseConstants = makeFunctionConstants()
      denseConstants.setConstantValue(&plainScratch, type: .bool, index: 1)
      let detectorDenseCompaction = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorDenseCompactionFunction,
        constantValues: denseConstants)
      detectorDenseCompactionPipeline = try device.makeComputePipelineState(
        function: detectorDenseCompaction)
    } else {
      detectorDenseCompactionPipeline = nil
    }
    detectorPartialsPipeline = try device.makeComputePipelineState(function: detectorPartials)
    if ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PREPARE_PARTIAL_STORES"] == "1" {
      var enabled = true
      let constants = makeFunctionConstants()
      constants.setConstantValue(&enabled, type: .bool, index: 8)
      let function = try library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSDetectorPartialsFunction,
        constantValues: constants)
      detectorPartialStoresPipeline = try device.makeComputePipelineState(function: function)
    } else {
      detectorPartialStoresPipeline = nil
    }
    detectorFinishPipeline = try device.makeComputePipelineState(function: detectorFinish)
    shape = [
      source.dataset.scanRows, source.dataset.scanCols,
      source.dataset.detectorRows, source.dataset.detectorCols,
    ]
    logicalDtype = source.sourceBytesPerValue == 1 ? .uint8 : .uint16
    sourceIdentitySHA256 = identity
    self.dpcMoments = dpcMoments
    let consolidationStarted = CFAbsoluteTimeGetCurrent()
    let consolidated = try Self.consolidate(
      provider: provider, library: library, queue: queue,
      compactOffsetsEnabled: compactOffsetSetting)
    payload = consolidated.payload
    offsets = consolidated.offsets
    modes = consolidated.modes
    decodingTable = provider.decodingTable
    loadMetrics = MetalPairedRuntimeTANSBuildMetrics(
      totalSeconds: CFAbsoluteTimeGetCurrent() - loadStarted,
      fusedDecodeAndSizeSeconds: metrics.fusedDecodeAndSizeSeconds,
      provisionalCPUPrefixSeconds: metrics.provisionalCPUPrefixSeconds,
      compactSeconds: metrics.compactSeconds,
      consolidationSeconds: CFAbsoluteTimeGetCurrent() - consolidationStarted,
      residentBytes: consolidated.residentBytes + UInt64(provider.decodingTable.length))
    let pixels = shape[2] * shape[3]
    failure = try Self.buffer(
      device: device, bytes: 4, options: .storageModeShared,
      label: "paired-runtime query failure")
    diffraction = try Self.buffer(
      device: device, bytes: pixels * 4, options: .storageModeShared,
      label: "paired-runtime diffraction")
    detectorProduct = try Self.buffer(
      device: device, bytes: shape[0] * shape[1] * 4, options: .storageModeShared,
      label: "paired-runtime detector product")
    let historySetting = ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_HISTORY"] ?? "0"
    guard historySetting == "0" || historySetting == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_HISTORY must be 0 or 1")
    }
    historyEnabled = historySetting == "1"
    if historyEnabled {
      historyProduct = try Self.buffer(
        device: device, bytes: shape[0] * shape[1] * 4, options: .storageModeShared,
        label: "paired-runtime detector history")
      memset(historyProduct!.contents(), 0, historyProduct!.length)
      historyMask = [UInt8](repeating: 0, count: pixels)
    } else {
      historyProduct = nil
      historyMask = nil
    }
    detectorMask = [UInt8](repeating: 0, count: pixels)
    var valid = [UInt8](repeating: 1, count: pixels)
    for pixel in source.dataset.badPixelIndices where valid.indices.contains(pixel) {
      valid[pixel] = 0
    }
    validPixels = valid
    let polarSetting = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_POLAR_INDEX"] ?? "0"
    guard polarSetting == "0" || polarSetting == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_POLAR_INDEX must be 0 or 1")
    }
    if polarSetting == "1" {
      let leafSetting = ProcessInfo.processInfo.environment[
        "QGPU_PAIRED_RUNTIME_POLAR_LEAF_PIXELS"] ?? "64"
      guard let leafPixels = Int(leafSetting), [16, 32, 64].contains(leafPixels) else {
        throw Self.invalid("QGPU_PAIRED_RUNTIME_POLAR_LEAF_PIXELS must be 16, 32, or 64")
      }
      let layoutKind = ProcessInfo.processInfo.environment[
        "QGPU_PAIRED_RUNTIME_POLAR_LAYOUT"] ?? "polar"
      guard ["polar", "radial1", "radialhalf"].contains(layoutKind) else {
        throw Self.invalid("QGPU_PAIRED_RUNTIME_POLAR_LAYOUT must be polar, radial1, or radialhalf")
      }
      polarIndex = try autoreleasepool {
        try MetalPairedRuntimeTANSPolarIndex(
          device: device, library: library, queue: queue, payload: payload,
          offsets: offsets, modes: modes, decoding: decodingTable,
          validPixels: valid, packets: shape[0] * shape[1] / 512,
          leafPixels: leafPixels, layoutKind: layoutKind,
          compactOffsetsEnabled: compactOffsetSetting)
      }
      let previous = loadMetrics
      loadMetrics = MetalPairedRuntimeTANSBuildMetrics(
        totalSeconds: CFAbsoluteTimeGetCurrent() - loadStarted,
        fusedDecodeAndSizeSeconds: previous.fusedDecodeAndSizeSeconds,
        provisionalCPUPrefixSeconds: previous.provisionalCPUPrefixSeconds,
        compactSeconds: previous.compactSeconds,
        consolidationSeconds: previous.consolidationSeconds,
        residentBytes: previous.residentBytes)
    }
    refreshMetadataSnapshot()
  }

  /// Return one exact diffraction pattern, widened only for the public API.
  public func extractRawDiffraction(scanRow: Int, scanColumn: Int) throws -> [UInt32] {
    stateLock.lock()
    defer { stateLock.unlock() }
    try requireLive()
    guard (0..<shape[0]).contains(scanRow), (0..<shape[1]).contains(scanColumn) else {
      throw Self.invalid("Choose an in-bounds scan row and column")
    }
    let scan = scanRow * shape[1] + scanColumn
    memset(failure.contents(), 0, 4)
    guard let command = queue.makeCommandBuffer(),
      let encoder = command.makeComputeCommandEncoder()
    else { throw Self.invalid("Metal could not encode a paired-runtime diffraction query") }
    var parameters: [UInt32] = [
      UInt32(shape[2] * shape[3]),
      UInt32(shape[0] * shape[1] / PairedRuntimeTANSRecordABI.streamScans),
      UInt32(scan), UInt32(payload.length),
    ]
    encoder.setComputePipelineState(selectedDPPipeline)
    for (index, buffer) in [
      payload, offsets, modes, decodingTable,
      diffraction, failure,
    ].enumerated() {
      encoder.setBuffer(buffer, offset: 0, index: index)
    }
    encoder.setBytes(&parameters, length: parameters.count * 4, index: 6)
    let width = selectedDPPipeline.threadExecutionWidth
    encoder.dispatchThreads(
      MTLSize(width: shape[2] * shape[3], height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(
        width: min(selectedDPPipeline.maxTotalThreadsPerThreadgroup, width * 4),
        height: 1, depth: 1))
    encoder.endEncoding()
    try finish(command, operation: "diffraction")
    return Array(
      UnsafeBufferPointer(
        start: diffraction.contents().assumingMemoryBound(to: UInt32.self),
        count: shape[2] * shape[3]))
  }

  private struct UpdateProfile {
    let requestEntry: Double
    let preparationStart: Double
    var planningStart: Double = 0
    var planningEnd: Double = 0
    var preparationEnd: Double = 0
    var commitHost: Double = 0
    var waitCompletionHost: Double = 0
    var readbackStart: Double = 0
    var readbackEnd: Double = 0
    var gpuStart: Double = 0
    var gpuEnd: Double = 0
    var profileResolveMilliseconds: Double = 0
    var stageResult: PairedRuntimeDetectorProfiler.StageResult?

    var values: [String: Double] {
      var result: [String: Double] = [
        "cpu_request_entry_seconds": requestEntry,
        "cpu_preparation_start_seconds": preparationStart,
        "cpu_planning_start_seconds": planningStart,
        "cpu_planning_end_seconds": planningEnd,
        "cpu_preparation_end_seconds": preparationEnd,
        "cpu_planning_milliseconds": max(0, planningEnd - planningStart) * 1_000,
        "cpu_preparation_milliseconds": max(0, preparationEnd - preparationStart) * 1_000,
        "host_commit_seconds": commitHost,
        "host_wait_completion_seconds": waitCompletionHost,
        "host_readback_milliseconds": max(0, readbackEnd - readbackStart) * 1_000,
        "host_profile_resolve_milliseconds": profileResolveMilliseconds,
        "command_gpu_start_seconds": gpuStart,
        "command_gpu_end_seconds": gpuEnd,
        "command_gpu_milliseconds": max(0, gpuEnd - gpuStart) * 1_000,
      ]
      if let stageResult {
        result["stage_profile_valid"] = stageResult.valid ? 1 : 0
        result["stage_command_milliseconds"] = stageResult.commandNanoseconds / 1_000_000
        result["stage_encoder_union_milliseconds"] =
          stageResult.encoderUnionNanoseconds / 1_000_000
        if let scale = stageResult.calibratedNanosecondsPerTick {
          result["stage_calibrated_nanoseconds_per_tick"] = scale
        }
        for (name, nanoseconds) in stageResult.stageNanoseconds {
          result["stage_\(name)_milliseconds"] = nanoseconds / 1_000_000
        }
        for (name, seconds) in stageResult.stageTimeline {
          result[name] = seconds
        }
      }
      return result
    }
  }

  private struct PendingDetectorUpdate {
    let command: MTLCommandBuffer?
    let mask: [UInt8]
    let previousMask: [UInt8]
    let started: Double
    let changedCount: Int
    let operation: String
    let candidateProduct: MTLBuffer?
    let historyHit: Bool
    let historyBase: Bool
    let previousHistoryValid: Bool
    let previousPolarFieldCount: Int
    let previousPolarResidualCount: Int
    let profile: UpdateProfile?
    let stageSession: PairedRuntimeDetectorProfiler.Session?
    let keepAlive: [MTLBuffer]
  }

  public typealias DetectorUpdateResult = (
    values: [UInt32], wallMilliseconds: Double, gpuMilliseconds: Double,
    changedDetectorPixels: Int
  )
  @_spi(PairedRuntimeTANSPrototype)
  public typealias DetectorDecodeChecksumResult = (
    values: [UInt32], wallMilliseconds: Double, gpuMilliseconds: Double
  )

  /// Update one exact virtual-detector image using only changed mask pixels.
  public func updateVirtualDetector(mask: [UInt8]) throws -> DetectorUpdateResult {
    stateLock.lock()
    defer { stateLock.unlock() }
    return try finishDetectorUpdate(try prepareDetectorUpdate(mask: mask))
  }

  /// Run the FC14 decode-coverage diagnostic without changing detector state.
  /// The result contains one wraparound UInt32 checksum for each 512-scan
  /// packet; it is not an image and must not be used as a parity or speed path.
  @_spi(PairedRuntimeTANSPrototype)
  public func detectorDecodeChecksum(mask: [UInt8]) throws -> DetectorDecodeChecksumResult {
    stateLock.lock()
    defer { stateLock.unlock() }
    try requireLive()
    guard let pipeline = detectorDecodeChecksumPipeline else {
      throw Self.invalid(
        "Prepare the FC14 decode-checksum pipeline with "
          + "QGPU_PAIRED_RUNTIME_PREPARE_DECODE_CHECKSUM=1 before loading the resident")
    }
    let pixels = shape[2] * shape[3]
    guard mask.count == pixels, mask.allSatisfy({ $0 == 0 || $0 == 1 }) else {
      throw Self.invalid("The decode-checksum mask must contain one binary value per pixel")
    }
    var selected: [UInt32] = []
    selected.reserveCapacity(mask.reduce(0) { $0 + ($1 == 0 ? 0 : 1) })
    for pixel in mask.indices where mask[pixel] != 0 && validPixels[pixel] != 0 {
      selected.append(UInt32(pixel))
    }
    let packets = shape[0] * shape[1] / PairedRuntimeTANSRecordABI.streamScans
    let selectedBuffer = try Self.upload(
      selected.isEmpty ? [0] : selected, device: detectorProduct.device,
      label: "paired-runtime decode-checksum selected pixels")
    let coefficients = try Self.upload(
      [Int32](repeating: 1, count: max(1, selected.count)), device: detectorProduct.device,
      label: "paired-runtime decode-checksum coefficients")
    let checksums = try Self.buffer(
      device: detectorProduct.device, bytes: packets * MemoryLayout<UInt32>.stride,
      options: .storageModeShared, label: "paired-runtime decode-checksum output")
    let localFailure = try Self.buffer(
      device: detectorProduct.device, bytes: MemoryLayout<UInt32>.stride,
      options: .storageModeShared, label: "paired-runtime decode-checksum failure")
    memset(checksums.contents(), 0, checksums.length)
    memset(localFailure.contents(), 0, localFailure.length)
    guard let command = queue.makeCommandBuffer(),
      let encoder = command.makeComputeCommandEncoder()
    else { throw Self.invalid("Metal could not encode the FC14 decode checksum") }
    var parameters: [UInt32] = [
      UInt32(pixels), UInt32(packets), UInt32(selected.count), 0,
      UInt32(payload.length), 1,
    ]
    encoder.setComputePipelineState(pipeline)
    for (index, buffer) in [
      payload, offsets, modes, decodingTable, selectedBuffer, coefficients,
      checksums, localFailure,
    ].enumerated() {
      encoder.setBuffer(buffer, offset: 0, index: index)
    }
    encoder.setBytes(&parameters, length: parameters.count * MemoryLayout<UInt32>.stride, index: 8)
    encoder.dispatchThreadgroups(
      MTLSize(width: (packets + 3) / 4, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
    encoder.endEncoding()
    let started = CFAbsoluteTimeGetCurrent()
    command.commit()
    command.waitUntilCompleted()
    let code = localFailure.contents().load(as: UInt32.self)
    guard command.status == .completed, command.error == nil, code == 0 else {
      throw Self.invalid(
        "Paired-runtime FC14 decode checksum failed with code \(code): "
          + (command.error?.localizedDescription ?? "invalid stream"))
    }
    let values = Array(
      UnsafeBufferPointer(
        start: checksums.contents().assumingMemoryBound(to: UInt32.self), count: packets))
    return (
      values, (CFAbsoluteTimeGetCurrent() - started) * 1_000,
      max(0, command.gpuEndTime - command.gpuStartTime) * 1_000)
  }

  /// Diagnostic signed contribution, independent of the current image/history.
  /// Scratch byte counts sum requested Metal buffer lengths, excluding host arrays
  /// and driver overhead. Reuse retains one exact mask pair until replacement/release.
  @_spi(PairedRuntimeTANSPrototype)
  public func isolateDetectorStage(previous: [UInt8], target: [UInt8], stage: String,
    branchlessPop: Bool = false, reuseScratch: Bool = false, refillThreshold: Int = 32,
    phasedReaders: Bool = false, pairUnroll: Int = 1)
    throws -> (values: [UInt32], gpuMilliseconds: Double, fields: Int, residuals: Int,
      allocatedScratchBytes: Int, preparedScratchBytes: Int, reusedScratch: Bool) {
    stateLock.lock()
    defer {
      refreshMetadataSnapshot()
      stateLock.unlock()
    }
    try requireLive()
    guard let polarIndex, ["index", "residual", "combined"].contains(stage),
      previous.count == validPixels.count, target.count == validPixels.count,
      previous.allSatisfy({ $0 <= 1 }), target.allSatisfy({ $0 <= 1 })
    else { throw Self.invalid("Stage isolation requires a prepared index and binary detector masks") }
    guard [16, 24, 32].contains(refillThreshold), !branchlessPop || refillThreshold == 32 else {
      throw Self.invalid("Use refillThreshold 16, 24, or 32; branchlessPop requires 32")
    }
    guard !phasedReaders || (!branchlessPop && refillThreshold == 32) else {
      throw Self.invalid("phasedReaders requires branchlessPop=false and refillThreshold=32")
    }
    guard [1, 2, 4, 8].contains(pairUnroll),
      pairUnroll == 1 || (!branchlessPop && refillThreshold == 32 && !phasedReaders) else {
      throw Self.invalid(
        "Use pairUnroll 1, 2, 4, or 8; unrolling requires branchlessPop=false, "
          + "refillThreshold=32, and phasedReaders=false")
    }
    let scratch: DiagnosticScratch
    let reused: Bool
    let jointPlanEnabled = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_JOINT_PLAN"] == "1"
    if reuseScratch, let cached = diagnosticScratch,
      cached.jointPlanEnabled == jointPlanEnabled,
      cached.previous == previous, cached.target == target {
      scratch = cached
      reused = true
    } else {
      // Drop the previous diagnostic allocation before preparing another mask pair.
      if reuseScratch { diagnosticScratch = nil }
      let delta = target.indices.map {
        validPixels[$0] == 0 ? Int32(0) : Int32(target[$0]) - Int32(previous[$0])
      }
      let plan = PairedRuntimeTANSPolarPlan.make(
        delta: delta, validPixels: validPixels, detectorRows: shape[2],
        detectorColumns: shape[3], leafPixels: polarIndex.leafPixels,
        layoutKind: polarIndex.layoutKind)
      let device = queue.device
      let output = try Self.buffer(device: device, bytes: detectorProduct.length,
        options: .storageModeShared, label: "diagnostic stage contribution")
      let status = try Self.buffer(device: device, bytes: 4,
        options: .storageModeShared, label: "diagnostic stage status")
      let selected = try Self.upload(plan.residualPixels.isEmpty ? [0] : plan.residualPixels,
        device: device, label: "diagnostic residual pixels")
      let coefficients = try Self.upload(
        plan.residualCoefficients.isEmpty ? [0] : plan.residualCoefficients,
        device: device, label: "diagnostic residual coefficients")
      let indexInputs = reuseScratch || stage != "residual"
        ? try polarIndex.prepareInputs(plan: plan) : nil
      scratch = DiagnosticScratch(jointPlanEnabled: jointPlanEnabled,
        previous: previous, target: target, plan: plan,
        output: output, status: status, selected: selected, coefficients: coefficients,
        indexInputs: indexInputs)
      reused = false
      if reuseScratch {
        diagnosticScratch = scratch
      }
    }
    let plan = scratch.plan
    let output = scratch.output
    let status = scratch.status
    let selected = scratch.selected
    let coefficients = scratch.coefficients
    memset(output.contents(), 0, output.length)
    memset(status.contents(), 0, status.length)
    guard let command = queue.makeCommandBuffer() else { throw Self.invalid("No diagnostic command") }
    if stage != "residual" {
      try polarIndex.encode(inputs: scratch.indexInputs!, output: output,
        failure: status, command: command)
    }
    if stage != "index" && !plan.residualPixels.isEmpty {
      guard let encoder = command.makeComputeCommandEncoder() else {
        throw Self.invalid("No diagnostic encoder")
      }
      let packets = shape[0] * shape[1] / 512
      var parameters: [UInt32] = [UInt32(validPixels.count), UInt32(packets),
        UInt32(plan.residualPixels.count), 0, UInt32(payload.length), 1]
      if branchlessPop {
        guard let pipeline = detectorBranchlessPopPipeline else {
          throw Self.invalid("Prepare branchless-pop diagnostic before loading")
        }
        encoder.setComputePipelineState(pipeline)
      } else if refillThreshold != 32 {
        guard let pipeline = detectorRefillPipelines[refillThreshold] else {
          throw Self.invalid("Set QGPU_PREPARE_REFILL_THRESHOLDS=1 before loading")
        }
        encoder.setComputePipelineState(pipeline)
      } else if phasedReaders {
        guard let pipeline = detectorPhasedReadersPipeline else {
          throw Self.invalid("Set QGPU_PREPARE_PHASED_READERS=1 before loading")
        }
        encoder.setComputePipelineState(pipeline)
      } else if pairUnroll != 1 {
        guard let pipeline = detectorPairUnrollPipelines[pairUnroll] else {
          throw Self.invalid("Set QGPU_PREPARE_PAIR_UNROLL=1 before loading")
        }
        encoder.setComputePipelineState(pipeline)
      } else { encoder.setComputePipelineState(detectorPacketOwner2Pipeline) }
      for (index, buffer) in [payload, offsets, modes, decodingTable, selected,
        coefficients, output, status].enumerated() {
        encoder.setBuffer(buffer, offset: 0, index: index)
      }
      encoder.setBytes(&parameters, length: 24, index: 8)
      encoder.dispatchThreadgroups(MTLSize(width: (packets + 3) / 4, height: 1, depth: 1),
        threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
      encoder.endEncoding()
    }
    command.commit()
    command.waitUntilCompleted()
    guard command.status == .completed, status.contents().load(as: UInt32.self) == 0 else {
      throw Self.invalid("Stage isolation GPU failure")
    }
    return (Array(UnsafeBufferPointer(start: output.contents().assumingMemoryBound(to: UInt32.self),
      count: shape[0] * shape[1])), (command.gpuEndTime - command.gpuStartTime) * 1000,
      plan.selectedFields.count, plan.residualPixels.count,
      reused ? 0 : scratch.byteCount, scratch.byteCount, reused)
  }

  /// Submit one detector update for every unique resident, then complete them.
  @_spi(PairedRuntimeTANSPrototype)
  public static func updateVirtualDetectors(
    sources: [MetalPairedRuntimeTANSResidentSource], mask: [UInt8]
  ) throws -> [DetectorUpdateResult] {
    try updateVirtualDetectors(
      sources: sources, masks: Array(repeating: mask, count: sources.count))
  }

  /// Submit source-specific detector masks for every unique resident.
  @_spi(PairedRuntimeTANSPrototype)
  public static func updateVirtualDetectors(
    sources: [MetalPairedRuntimeTANSResidentSource], masks: [[UInt8]]
  ) throws -> [DetectorUpdateResult] {
    guard sources.count == masks.count else {
      throw Self.invalid("A paired-runtime detector batch requires one mask per resident")
    }
    var ordered = Array(sources.enumerated())
    guard Set(sources.map { ObjectIdentifier($0) }).count == sources.count else {
      throw Self.invalid("A paired-runtime detector batch cannot contain duplicate residents")
    }
    ordered.sort {
      UInt(bitPattern: Unmanaged.passUnretained($0.element).toOpaque())
        < UInt(bitPattern: Unmanaged.passUnretained($1.element).toOpaque())
    }
    for entry in ordered { entry.element.stateLock.lock() }
    defer { for entry in ordered.reversed() { entry.element.stateLock.unlock() } }

    var pending: [(offset: Int, resident: MetalPairedRuntimeTANSResidentSource,
      update: PendingDetectorUpdate)] = []
    do {
      for entry in ordered {
        pending.append((entry.offset, entry.element,
          try entry.element.prepareDetectorUpdate(mask: masks[entry.offset])))
      }
    } catch {
      for item in pending { item.resident.rollbackPreparedDetectorUpdate(item.update) }
      throw error
    }

    // Commit every resident before waiting on any one resident.
    var commitTimes: [ObjectIdentifier: Double] = [:]
    for item in pending {
      let commitTime = item.update.profile == nil ? 0 : ProcessInfo.processInfo.systemUptime
      if item.update.command != nil { item.update.stageSession?.willCommit() }
      item.update.command?.commit()
      if commitTime != 0 { commitTimes[ObjectIdentifier(item.resident)] = commitTime }
    }
    var results = [DetectorUpdateResult?](repeating: nil, count: sources.count)
    var firstError: Error?
    for item in pending {
      do {
        results[item.offset] = try item.resident.finishDetectorUpdate(
          item.update, commit: false, commitHost: commitTimes[ObjectIdentifier(item.resident)])
      } catch {
        firstError = firstError ?? error
      }
    }
    if let firstError { throw firstError }
    return results.compactMap { $0 }
  }

  /// Return process-wide polar-plan cache counters for benchmark diagnostics.
  @_spi(PairedRuntimeTANSPrototype)
  public static func polarPlanCacheProfileSnapshot() -> [String: Double] {
    PairedRuntimeTANSPolarPlan.cacheProfileSnapshot()
  }

  private func prepareDetectorUpdate(mask: [UInt8]) throws -> PendingDetectorUpdate {
    let profileEnabled = ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PROFILE"] == "1"
    let requestEntry = profileEnabled ? ProcessInfo.processInfo.systemUptime : 0
    let preparationStart = profileEnabled ? ProcessInfo.processInfo.systemUptime : 0
    var profile = profileEnabled
      ? UpdateProfile(requestEntry: requestEntry, preparationStart: preparationStart)
      : nil
    let stageSession = profileEnabled ? detectorProfiler?.makeSession() : nil
    try requireLive()
    let historyActive = historyEnabled
      && ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_HISTORY"] == "1"
    let previousHistoryValid = historyValid
    let previousPolarFields = polarFieldCount
    let previousPolarResiduals = polarResidualCount
    var preparationSucceeded = false
    defer {
      if historyActive && !preparationSucceeded {
        historyValid = previousHistoryValid
        polarFieldCount = previousPolarFields
        polarResidualCount = previousPolarResiduals
        refreshMetadataSnapshot()
      }
    }
    if !historyActive { historyValid = false }
    metadataLock.lock()
    cachedHistoryHit = false
    cachedHistoryBase = false
    metadataLock.unlock()
    if profileEnabled {
      metadataLock.lock()
      cachedUpdateProfile = [:]
      metadataLock.unlock()
    }
    let pixels = shape[2] * shape[3]
    if profileEnabled { profile?.planningStart = ProcessInfo.processInfo.systemUptime }
    guard mask.count == pixels, mask.allSatisfy({ $0 == 0 || $0 == 1 }) else {
      throw Self.invalid("The paired-runtime detector mask must contain one binary value per pixel")
    }
    var selected: [UInt32] = []
    var coefficients: [Int32] = []
    selected.reserveCapacity(pixels)
    coefficients.reserveCapacity(pixels)
    for pixel in 0..<pixels where mask[pixel] != detectorMask[pixel] {
      selected.append(UInt32(pixel))
      coefficients.append(mask[pixel] == 1 ? 1 : -1)
    }
    guard !selected.isEmpty else {
      if profileEnabled {
        let completed = ProcessInfo.processInfo.systemUptime
        profile?.planningEnd = completed
        profile?.preparationEnd = completed
      }
      preparationSucceeded = true
      return PendingDetectorUpdate(
        command: nil, mask: mask, previousMask: detectorMask, started: 0,
        changedCount: 0, operation: "detector", candidateProduct: nil,
        historyHit: false, historyBase: false, previousHistoryValid: previousHistoryValid,
        previousPolarFieldCount: previousPolarFields,
        previousPolarResidualCount: previousPolarResiduals, profile: profile,
        stageSession: stageSession, keepAlive: [])
    }
    let changedCount = selected.count
    let previousMask = detectorMask
    if historyActive, historyValid, historyMask == mask {
      if profileEnabled {
        let completed = ProcessInfo.processInfo.systemUptime
        profile?.planningEnd = completed
        profile?.preparationEnd = completed
      }
      preparationSucceeded = true
      return PendingDetectorUpdate(
        command: nil, mask: mask, previousMask: previousMask, started: 0,
        changedCount: changedCount, operation: "detector history", candidateProduct: nil,
        historyHit: true, historyBase: false, previousHistoryValid: previousHistoryValid,
        previousPolarFieldCount: previousPolarFields,
        previousPolarResidualCount: previousPolarResiduals, profile: profile,
        stageSession: stageSession, keepAlive: [])
    }
    var polarPlan: PairedRuntimeTANSPolarPlan?
    var startFromZero = false
    var usingHistoryBase = false
    let chooseBaseValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_CHOOSE_BASE"] ?? "0"
    guard chooseBaseValue == "0" || chooseBaseValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_CHOOSE_BASE must be 0 or 1")
    }
    let historyBaseValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_HISTORY_BASE"] ?? "0"
    guard historyBaseValue == "0" || historyBaseValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_HISTORY_BASE must be 0 or 1")
    }
    let requestHistoryBase = historyBaseValue == "1"
    guard !requestHistoryBase || historyActive else {
      throw Self.invalid(
        "QGPU_PAIRED_RUNTIME_HISTORY_BASE=1 requires QGPU_PAIRED_RUNTIME_HISTORY=1 and startup history storage")
    }
    // The public low-level mask API can still include invalid detector pixels.
    // Its exact raw-mask semantics use the direct path; indexed fields exclude
    // invalid pixels and are used only when both masks follow that policy.
    let indexRequested = polarIndex != nil
      && ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_POLAR_INDEX"] == "1"
    let currentIndexAllowed = indexRequested && !validPixels.indices.contains(where: {
      validPixels[$0] == 0 && (mask[$0] != 0 || detectorMask[$0] != 0)
    })
    let historyIndexAllowed = currentIndexAllowed && historyValid
      && historyMask != nil && !validPixels.indices.contains(where: {
        validPixels[$0] == 0 && (mask[$0] != 0 || historyMask![$0] != 0)
      })
    if let polarIndex, currentIndexAllowed {
      var delta = [Int32](repeating: 0, count: pixels)
      for (pixel, coefficient) in zip(selected, coefficients) {
        delta[Int(pixel)] = coefficient
      }
      let previousPlan = PairedRuntimeTANSPolarPlan.make(
        delta: delta, validPixels: validPixels,
        detectorRows: shape[2], detectorColumns: shape[3], leafPixels: polarIndex.leafPixels,
        layoutKind: polarIndex.layoutKind)
      var plan = previousPlan
      var selectedCost = previousPlan.estimatedCost
      if chooseBaseValue == "1" {
        let absolute = mask.map(Int32.init)
        let zeroPlan = PairedRuntimeTANSPolarPlan.make(
          delta: absolute, validPixels: validPixels,
          detectorRows: shape[2], detectorColumns: shape[3], leafPixels: polarIndex.leafPixels,
          layoutKind: polarIndex.layoutKind)
        // Charge one field-equivalent for clearing the complete output. A tie
        // stays on the previous base, avoiding an unnecessary full-buffer write.
        if zeroPlan.estimatedCost + 1 < previousPlan.estimatedCost {
          plan = zeroPlan
          startFromZero = true
          selectedCost = zeroPlan.estimatedCost + 1 // account for clearing the candidate output
        }
      }
      if requestHistoryBase, historyIndexAllowed {
        var historyDelta = [Int32](repeating: 0, count: pixels)
        for pixel in 0..<pixels where mask[pixel] != historyMask![pixel] {
          historyDelta[pixel] = mask[pixel] == 1 ? 1 : -1
        }
        let historyPlan = PairedRuntimeTANSPolarPlan.make(
          delta: historyDelta, validPixels: validPixels,
          detectorRows: shape[2], detectorColumns: shape[3], leafPixels: polarIndex.leafPixels,
          layoutKind: polarIndex.layoutKind)
        let historyCost = historyPlan.estimatedCost
        let currentCost = previousPlan.estimatedCost
        let paretoDominates = { (candidate: PairedRuntimeTANSPolarPlan,
                                 baseline: PairedRuntimeTANSPolarPlan) -> Bool in
          let residualNoMore = candidate.residualPixels.count <= baseline.residualPixels.count
          let fieldsNoMore = candidate.selectedFields.count <= baseline.selectedFields.count
          let oneStrict = candidate.residualPixels.count < baseline.residualPixels.count
            || candidate.selectedFields.count < baseline.selectedFields.count
          return residualNoMore && fieldsNoMore && oneStrict
        }
        // The planner's scalar estimate can trade many residual pixels for a
        // few fields too aggressively. Require a Pareto improvement over both
        // the current plan and a cheaper zero-based plan, if one was selected.
        if historyCost < currentCost && historyCost < selectedCost
          && paretoDominates(historyPlan, previousPlan)
          && paretoDominates(historyPlan, plan) {
          plan = historyPlan
          startFromZero = false
          usingHistoryBase = true
          selectedCost = historyCost
        }
      }
      if plan.usedIndex {
        polarPlan = plan
        selected = plan.residualPixels
        coefficients = plan.residualCoefficients
      } else if startFromZero || usingHistoryBase {
        selected = plan.residualPixels
        coefficients = plan.residualCoefficients
      }
    } else if requestHistoryBase, historyValid, let historyMask {
      var historySelected: [UInt32] = []
      var historyCoefficients: [Int32] = []
      historySelected.reserveCapacity(changedCount)
      historyCoefficients.reserveCapacity(changedCount)
      for pixel in 0..<pixels where mask[pixel] != historyMask[pixel] {
        historySelected.append(UInt32(pixel))
        historyCoefficients.append(mask[pixel] == 1 ? 1 : -1)
      }
      // Raw mode charges one work item per changed detector pixel. Ties stay
      // on the current product so the history path is strictly opt-in.
      if historySelected.count < selected.count {
        selected = historySelected
        coefficients = historyCoefficients
        usingHistoryBase = true
      }
    }
    if profileEnabled { profile?.planningEnd = ProcessInfo.processInfo.systemUptime }
    polarFieldCount = polarPlan?.selectedFields.count ?? 0
    polarResidualCount = selected.count
    refreshMetadataSnapshot()
    let selectedBuffer = try Self.upload(
      selected.isEmpty ? [0] : selected,
      device: detectorProduct.device, label: "paired-runtime selected pixels")
    let coefficientBuffer = try Self.upload(
      coefficients.isEmpty ? [0] : coefficients,
      device: detectorProduct.device, label: "paired-runtime coefficients")
    let outputProduct: MTLBuffer
    if historyActive {
      guard let historyProduct else {
        throw Self.invalid("Paired-runtime history storage is unavailable")
      }
      outputProduct = historyProduct
    } else {
      outputProduct = detectorProduct
    }
    memset(failure.contents(), 0, 4)
    guard let command = queue.makeCommandBuffer() else {
      throw Self.invalid("Metal could not encode a paired-runtime detector query")
    }
    let started = CFAbsoluteTimeGetCurrent()
    if historyActive && !startFromZero && !usingHistoryBase {
      guard let blit = command.makeBlitCommandEncoder() else {
        throw Self.invalid("Metal could not copy the paired-runtime detector history")
      }
      blit.copy(
        from: detectorProduct, sourceOffset: 0, to: outputProduct, destinationOffset: 0,
        size: detectorProduct.length)
      blit.endEncoding()
    }
    if startFromZero {
      guard let blit = command.makeBlitCommandEncoder() else {
        throw Self.invalid("Metal could not clear a zero-based paired-runtime detector query")
      }
      blit.fill(buffer: outputProduct, range: 0..<outputProduct.length, value: 0)
      blit.endEncoding()
    }
    if let polarPlan, let polarIndex {
      try polarIndex.encode(
        plan: polarPlan, output: outputProduct, failure: failure, command: command,
        profiler: stageSession)
    }
    let packets = shape[0] * shape[1] / PairedRuntimeTANSRecordABI.streamScans
    if (polarPlan != nil || startFromZero) && selected.isEmpty {
      if profileEnabled { profile?.preparationEnd = ProcessInfo.processInfo.systemUptime }
      preparationSucceeded = true
      return PendingDetectorUpdate(
        command: command, mask: mask, previousMask: previousMask, started: started,
        changedCount: changedCount, operation: "polar-only detector",
        candidateProduct: historyActive ? outputProduct : nil, historyHit: false,
        historyBase: usingHistoryBase,
        previousHistoryValid: previousHistoryValid,
        previousPolarFieldCount: previousPolarFields,
        previousPolarResidualCount: previousPolarResiduals,
        profile: profile,
        stageSession: stageSession,
        keepAlive: [selectedBuffer, coefficientBuffer])
    }

    let detectorKernel = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_DETECTOR_KERNEL"] ?? "packet-owner2"
    guard ["packet-owner2", "partials", "adaptive-partials"].contains(detectorKernel) else {
      throw Self.invalid(
        "QGPU_PAIRED_RUNTIME_DETECTOR_KERNEL must be packet-owner2, partials, or adaptive-partials")
    }
    let lazyRefillValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_LAZY_REFILL"] ?? "0"
    guard lazyRefillValue == "0" || lazyRefillValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_LAZY_REFILL must be 0 or 1")
    }
    let lazyRefill = lazyRefillValue == "1"
    guard !lazyRefill || detectorKernel == "packet-owner2" else {
      throw Self.invalid("Lazy refill requires the ordinary packet-owner2 kernel")
    }
    let trustedTableValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_TRUSTED_TABLE"] ?? "0"
    guard trustedTableValue == "0" || trustedTableValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_TRUSTED_TABLE must be 0 or 1")
    }
    let trustedTable = trustedTableValue == "1"
    guard !trustedTable || detectorKernel == "packet-owner2" else {
      throw Self.invalid("Trusted table mode requires the packet-owner2 kernel")
    }
    let partialMaximumGroupsValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_PARTIAL_MAX_GROUPS"] ?? "8"
    guard let partialMaximumGroups = Int(partialMaximumGroupsValue),
      [8, 16, 32].contains(partialMaximumGroups)
    else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_PARTIAL_MAX_GROUPS must be 8, 16, or 32")
    }
    let adaptiveGroups = (selected.count + 63) / 64
    let requestedPartialBytes = adaptiveGroups * packets * 512 * MemoryLayout<UInt32>.stride
    if requestedPartialBytes <= 128 * 1024 * 1024 && (detectorKernel == "partials"
      || (detectorKernel == "adaptive-partials" && !selected.isEmpty
        && adaptiveGroups <= partialMaximumGroups))
    {
      // The partial kernel gives each 64-pixel block its own SIMD group and
      // removes the packet-owner atomics from the hot loop. Scratch is lazy
      // and reused, so ordinary loads keep their compact resident footprint.
      let groups = adaptiveGroups
      let partialBytes = groups * packets * 512 * MemoryLayout<UInt32>.stride
      if detectorPartials == nil || detectorPartials!.length < partialBytes {
        guard let next = detectorProduct.device.makeBuffer(
          length: max(partialBytes, MemoryLayout<UInt32>.stride), options: .storageModeShared)
        else { throw Self.invalid("Metal could not allocate exact detector partials") }
        next.label = "paired-runtime detector partials"
        detectorPartials = next
        refreshMetadataSnapshot()
      }
      guard let partials = detectorPartials,
        let encoder = stageSession?.makeComputeEncoder(
          commandBuffer: command, stage: "residual_partials")
          ?? command.makeComputeCommandEncoder()
      else { throw Self.invalid("Metal could not encode exact detector partials") }
      // This scratch uses shared storage and is consumed only after the
      // command is committed. Clearing it here avoids an additional blit
      // encoder, which older AGX drivers can reject before a compute encoder.
      let usePartialStores = ProcessInfo.processInfo.environment[
        "QGPU_PAIRED_RUNTIME_PARTIAL_STORES"] == "1"
      if usePartialStores && detectorPartialStoresPipeline == nil {
        throw Self.invalid("Prepare the partial-store pipeline before loading the resident")
      }
      if !usePartialStores { memset(partials.contents(), 0, partialBytes) }
      var partialParameters: [UInt32] = [
        UInt32(pixels), UInt32(packets), UInt32(selected.count), UInt32(groups),
        UInt32(payload.length),
      ]
      // Keep both dispatches in one compute encoder. AGX can reject adjacent
      // compute encoders in one command buffer while coalescing work; changing
      // the pipeline and bindings is equivalent and avoids that driver path.
      encoder.setComputePipelineState(
        usePartialStores ? detectorPartialStoresPipeline! : detectorPartialsPipeline)
      for (index, buffer) in [
        payload, offsets, modes, decodingTable, selectedBuffer, coefficientBuffer,
        partials, failure,
      ].enumerated() {
        encoder.setBuffer(buffer, offset: 0, index: index)
      }
      encoder.setBytes(
        &partialParameters, length: partialParameters.count * MemoryLayout<UInt32>.stride,
        index: 8)
      encoder.dispatchThreadgroups(
        MTLSize(width: groups, height: packets, depth: 1),
        threadsPerThreadgroup: MTLSize(width: 32, height: 1, depth: 1))
      // Keep both dispatches in their original encoder while profiling.
      let finishEncoder = encoder
      var finishParameters: [UInt32] = [UInt32(packets), UInt32(groups)]
      finishEncoder.setComputePipelineState(detectorFinishPipeline)
      finishEncoder.setBuffer(partials, offset: 0, index: 0)
      finishEncoder.setBuffer(outputProduct, offset: 0, index: 1)
      finishEncoder.setBytes(
        &finishParameters, length: finishParameters.count * MemoryLayout<UInt32>.stride,
        index: 2)
      let finishWidth = detectorFinishPipeline.threadExecutionWidth
      finishEncoder.dispatchThreads(
        MTLSize(width: packets * 512, height: 1, depth: 1),
        threadsPerThreadgroup: MTLSize(
          width: min(detectorFinishPipeline.maxTotalThreadsPerThreadgroup, finishWidth * 4),
          height: 1, depth: 1))
      finishEncoder.endEncoding()
      if profileEnabled { profile?.preparationEnd = ProcessInfo.processInfo.systemUptime }
      preparationSucceeded = true
      return PendingDetectorUpdate(
        command: command, mask: mask, previousMask: previousMask, started: started,
        changedCount: changedCount, operation: "detector partials",
        candidateProduct: historyActive ? outputProduct : nil, historyHit: false,
        historyBase: usingHistoryBase,
        previousHistoryValid: previousHistoryValid,
        previousPolarFieldCount: previousPolarFields,
        previousPolarResidualCount: previousPolarResiduals,
        profile: profile,
        stageSession: stageSession,
        keepAlive: [selectedBuffer, coefficientBuffer])
    }

    guard let encoder = stageSession?.makeComputeEncoder(
      commandBuffer: command, stage: "residual") ?? command.makeComputeCommandEncoder() else {
      throw Self.invalid("Metal could not encode a paired-runtime detector update")
    }
    let streamsPerLane = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_STREAMS_PER_LANE"] ?? "2"
    guard streamsPerLane == "1" || streamsPerLane == "2" || streamsPerLane == "4" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_STREAMS_PER_LANE must be 1, 2, or 4")
    }
    let sparseSplitValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_SPARSE_SPLIT"] ?? "0"
    guard sparseSplitValue == "0" || sparseSplitValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_SPARSE_SPLIT must be 0 or 1")
    }
    let sparseSplit = sparseSplitValue == "1"
    let denseCompactionValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_DENSE_COMPACTION"] ?? "0"
    guard denseCompactionValue == "0" || denseCompactionValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_DENSE_COMPACTION must be 0 or 1")
    }
    let denseCompaction = denseCompactionValue == "1"
    guard !denseCompaction || sparseSplit else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_DENSE_COMPACTION=1 requires sparse split")
    }
    let plainScratchValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_PLAIN_SCRATCH"] ?? "0"
    guard plainScratchValue == "0" || plainScratchValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_PLAIN_SCRATCH must be 0 or 1")
    }
    let macroValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_MACRO"] ?? "0"
    guard macroValue == "0" || macroValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_MACRO must be 0 or 1")
    }
    let macro = macroValue == "1"
    guard !macro || !denseCompaction else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_MACRO=1 requires dense compaction off")
    }
    let cooperativeValue = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_COOPERATIVE"] ?? "0"
    guard cooperativeValue == "0" || cooperativeValue == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_COOPERATIVE must be 0 or 1")
    }
    let cooperative = cooperativeValue == "1"
    guard !cooperative || (sparseSplit && !macro && !denseCompaction) else {
      throw Self.invalid(
        "QGPU_PAIRED_RUNTIME_COOPERATIVE=1 requires sparse split and disables macro/dense")
    }
    let reader32Value = ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_READER32"] ?? "0"
    guard reader32Value == "0" || reader32Value == "1" else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_READER32 must be 0 or 1")
    }
    let reader32 = reader32Value == "1"
    guard !reader32 || (!cooperative && !macro && !denseCompaction) else {
      throw Self.invalid("QGPU_PAIRED_RUNTIME_READER32=1 requires cooperative/macro/dense off")
    }
    guard let packetSplits = Int(ProcessInfo.processInfo.environment[
      "QGPU_PAIRED_RUNTIME_PACKET_SPLITS"] ?? "1"), [1, 2, 4, 8].contains(packetSplits)
    else { throw Self.invalid("Packet splits must be 1, 2, 4, or 8") }
    guard packetSplits == 1 || (streamsPerLane == "2" && !reader32 && !cooperative
      && !macro && !denseCompaction && !sparseSplit && detectorSplitPipelines[packetSplits] != nil)
    else { throw Self.invalid("Prepare packet-split pipelines and disable other packet specializations") }
    var parameters: [UInt32] = [
      UInt32(pixels), UInt32(packets), UInt32(selected.count), 0,
      UInt32(payload.length), sparseSplit ? 0 : 1,
    ]
    let reuseWord = ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_REUSE_WORD"] == "1"
    let registerSums = ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_REGISTER_SUMS"] == "1"
    let plainSums = ProcessInfo.processInfo.environment["QGPU_PAIRED_RUNTIME_PLAIN_SUMS"] == "1"
    guard !plainSums || (streamsPerLane == "2" && packetSplits == 1 && !reader32
      && !cooperative && !macro && !denseCompaction && !sparseSplit && !reuseWord && !registerSums)
    else { throw Self.invalid("Plain sums require the ordinary two-stream packet kernel") }
    guard !registerSums || (streamsPerLane == "2" && packetSplits == 1 && !reader32
      && !cooperative && !macro && !denseCompaction && !sparseSplit && !reuseWord)
    else { throw Self.invalid("Register sums require the ordinary two-stream packet kernel") }
    guard !reuseWord || (streamsPerLane == "2" && packetSplits == 1 && !reader32
      && !cooperative && !macro && !denseCompaction && !sparseSplit)
    else { throw Self.invalid("Word reuse requires the ordinary two-stream packet kernel") }
    guard !lazyRefill || (streamsPerLane == "2" && packetSplits == 1 && !reader32
      && !cooperative && !macro && !denseCompaction && !sparseSplit && !reuseWord
      && !registerSums && !plainSums && !trustedTable && detectorLazyRefillPipeline != nil)
    else {
      throw Self.invalid(
        "Lazy refill requires its prepared ordinary two-stream packet-owner2 pipeline")
    }
    guard !trustedTable || (streamsPerLane == "2" && packetSplits == 1 && !reader32
      && !cooperative && !macro && !denseCompaction && !sparseSplit && !reuseWord
      && !registerSums && !plainSums)
    else { throw Self.invalid("Trusted table requires the ordinary two-stream packet kernel") }
    if trustedTable {
      guard let detectorTrustedTablePipeline else {
        throw Self.invalid("Prepare the trusted-table pipeline before testing it")
      }
      encoder.setComputePipelineState(detectorTrustedTablePipeline)
    } else if plainSums {
      guard let detectorPlainSumsPipeline else {
        throw Self.invalid("Prepare the plain-sums pipeline before testing it")
      }
      encoder.setComputePipelineState(detectorPlainSumsPipeline)
    } else if registerSums {
      guard let detectorRegisterSumsPipeline else {
        throw Self.invalid("Prepare the register-sums pipeline before testing it")
      }
      encoder.setComputePipelineState(detectorRegisterSumsPipeline)
    } else if reuseWord {
      guard let detectorReuseWordPipeline else {
        throw Self.invalid("Prepare the word-reuse pipeline before testing it")
      }
      encoder.setComputePipelineState(detectorReuseWordPipeline)
    } else if lazyRefill {
      guard let detectorLazyRefillPipeline else {
        throw Self.invalid("Prepare the lazy-refill pipeline before testing it")
      }
      encoder.setComputePipelineState(detectorLazyRefillPipeline)
    } else if packetSplits > 1 {
      encoder.setComputePipelineState(detectorSplitPipelines[packetSplits]!)
    } else if reader32 {
      guard let detectorReader32Pipeline else {
        throw Self.invalid("Paired-runtime reader32 pipeline was not prepared")
      }
      encoder.setComputePipelineState(detectorReader32Pipeline)
    } else if cooperative {
      guard let detectorCooperativePipeline else {
        throw Self.invalid("Paired-runtime cooperative pipeline was not prepared")
      }
      encoder.setComputePipelineState(detectorCooperativePipeline)
    } else if macro {
      guard let detectorMacroPipeline, macroDecodingTable != nil else {
        throw Self.invalid("Paired-runtime macro pipeline was not prepared")
      }
      encoder.setComputePipelineState(detectorMacroPipeline)
    } else if denseCompaction {
      guard let detectorDenseCompactionPipeline else {
        throw Self.invalid("Paired-runtime dense-compaction pipeline was not prepared")
      }
      encoder.setComputePipelineState(detectorDenseCompactionPipeline)
    } else {
      encoder.setComputePipelineState(
        streamsPerLane == "4"
          ? detectorPacketOwner4Pipeline
          : streamsPerLane == "2" ? detectorPacketOwner2Pipeline : detectorPipeline)
    }
    let activeDecoding = macro ? macroDecodingTable! : decodingTable!
    for (index, buffer) in [
      payload, offsets, modes, activeDecoding, selectedBuffer, coefficientBuffer,
      outputProduct, failure,
    ].enumerated() {
      encoder.setBuffer(buffer, offset: 0, index: index)
    }
    encoder.setBytes(&parameters, length: parameters.count * 4, index: 8)
    encoder.dispatchThreadgroups(
      MTLSize(width: cooperative ? packets : ((packets + 3) / 4) * packetSplits, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(width: 128, height: 1, depth: 1))
    if sparseSplit {
      guard let detectorSparseScatterPipeline else {
        throw Self.invalid("Paired-runtime sparse-scatter pipeline was not prepared")
      }
      var sparseParameters: [UInt32] = [
        UInt32(pixels), UInt32(packets), UInt32(selected.count), UInt32(payload.length),
      ]
      encoder.setComputePipelineState(detectorSparseScatterPipeline)
      for (index, buffer) in [
        payload, offsets, modes, selectedBuffer, coefficientBuffer,
        outputProduct, failure,
      ].enumerated() {
        encoder.setBuffer(buffer, offset: 0, index: index)
      }
      encoder.setBytes(&sparseParameters, length: sparseParameters.count * 4, index: 7)
      let sparseWidth = detectorSparseScatterPipeline.threadExecutionWidth
      encoder.dispatchThreads(
        MTLSize(width: packets * selected.count, height: 1, depth: 1),
        threadsPerThreadgroup: MTLSize(
          width: min(
            detectorSparseScatterPipeline.maxTotalThreadsPerThreadgroup, sparseWidth * 4),
          height: 1, depth: 1))
    }
    encoder.endEncoding()
    if profileEnabled { profile?.preparationEnd = ProcessInfo.processInfo.systemUptime }
    preparationSucceeded = true
    return PendingDetectorUpdate(
      command: command, mask: mask, previousMask: previousMask, started: started,
      changedCount: changedCount, operation: "detector",
      candidateProduct: historyActive ? outputProduct : nil, historyHit: false,
      historyBase: usingHistoryBase,
      previousHistoryValid: previousHistoryValid,
      previousPolarFieldCount: previousPolarFields,
      previousPolarResidualCount: previousPolarResiduals,
      profile: profile,
      stageSession: stageSession,
      keepAlive: [selectedBuffer, coefficientBuffer])
  }

  private func finishDetectorUpdate(
    _ pending: PendingDetectorUpdate, commit shouldCommit: Bool = true,
    commitHost suppliedCommitHost: Double? = nil
  ) throws -> DetectorUpdateResult {
    var profile = pending.profile
    guard let command = pending.command else {
      if pending.historyHit {
        let oldProduct = detectorProduct
        detectorProduct = historyProduct!
        historyProduct = oldProduct
        let oldMask = detectorMask
        detectorMask = historyMask!
        historyMask = oldMask
        let oldFields = polarFieldCount
        polarFieldCount = historyPolarFieldCount
        historyPolarFieldCount = oldFields
        let oldResiduals = polarResidualCount
        polarResidualCount = historyPolarResidualCount
        historyPolarResidualCount = oldResiduals
        refreshMetadataSnapshot()
        metadataLock.lock()
        cachedHistoryHit = true
        cachedHistoryBase = false
        metadataLock.unlock()
      }
      if profile != nil {
        profile?.readbackStart = ProcessInfo.processInfo.systemUptime
        let values = detectorValues()
        profile?.readbackEnd = ProcessInfo.processInfo.systemUptime
        publishUpdateProfile(profile)
        return (values, 0, 0, pending.changedCount)
      }
      return (detectorValues(), 0, 0, pending.changedCount)
    }
    do {
      if shouldCommit {
        let commitHost = profile == nil ? 0 : ProcessInfo.processInfo.systemUptime
        pending.stageSession?.willCommit()
        command.commit()
        if commitHost != 0 { profile?.commitHost = commitHost }
      } else if let suppliedCommitHost {
        profile?.commitHost = suppliedCommitHost
      }
      let waitCompletionHost: Double
      command.waitUntilCompleted()
      waitCompletionHost = profile == nil ? 0 : ProcessInfo.processInfo.systemUptime
      if waitCompletionHost != 0 { profile?.waitCompletionHost = waitCompletionHost }
      let code = failure.contents().load(as: UInt32.self)
      guard command.status == .completed, command.error == nil, code == 0 else {
        throw Self.invalid(
          "Paired-runtime \(pending.operation) failed with code \(code): "
            + (command.error?.localizedDescription ?? "invalid stream"))
      }
    } catch {
      if pending.candidateProduct != nil {
        memset(pending.candidateProduct!.contents(), 0, pending.candidateProduct!.length)
        polarFieldCount = pending.previousPolarFieldCount
        polarResidualCount = pending.previousPolarResidualCount
        historyValid = false
        refreshMetadataSnapshot()
      } else {
        resetDetectorStateAfterFailedUpdate()
      }
      throw error
    }
    if let stageSession = pending.stageSession {
      let resolveStart = ProcessInfo.processInfo.systemUptime
      profile?.stageResult = stageSession.record(command: command)
      profile?.profileResolveMilliseconds =
        (ProcessInfo.processInfo.systemUptime - resolveStart) * 1_000
    }
    if let candidate = pending.candidateProduct {
      let oldProduct = detectorProduct
      detectorProduct = candidate
      historyProduct = oldProduct
      historyMask = pending.previousMask
      historyPolarFieldCount = pending.previousPolarFieldCount
      historyPolarResidualCount = pending.previousPolarResidualCount
      historyValid = true
    }
    detectorMask = pending.mask
    metadataLock.lock()
    cachedHistoryBase = pending.historyBase
    metadataLock.unlock()
    let values: [UInt32]
    if profile != nil {
      profile?.readbackStart = ProcessInfo.processInfo.systemUptime
      values = detectorValues()
      profile?.readbackEnd = ProcessInfo.processInfo.systemUptime
      profile?.gpuStart = command.gpuStartTime
      profile?.gpuEnd = command.gpuEndTime
      publishUpdateProfile(profile)
    } else {
      values = detectorValues()
    }
    return (
      values, (CFAbsoluteTimeGetCurrent() - pending.started) * 1_000,
      max(0, command.gpuEndTime - command.gpuStartTime) * 1_000,
      pending.changedCount)
  }

  /// Restore host metadata when a batch fails before command submission.
  /// No detector buffer has been modified at this point.
  private func rollbackPreparedDetectorUpdate(_ pending: PendingDetectorUpdate) {
    historyValid = pending.previousHistoryValid
    polarFieldCount = pending.previousPolarFieldCount
    polarResidualCount = pending.previousPolarResidualCount
    refreshMetadataSnapshot()
  }

  private func publishUpdateProfile(_ profile: UpdateProfile?) {
    guard let profile else { return }
    metadataLock.lock()
    cachedUpdateProfile = profile.values
    metadataLock.unlock()
  }

  /// Count stored modes touched by a detector mask without copying resident metadata.
  @_spi(PairedRuntimeTANSPrototype)
  public func detectorStreamModeCounts(mask: [UInt8]) throws -> [UInt32] {
    stateLock.lock()
    defer { stateLock.unlock() }
    try requireLive()
    let pixels = shape[2] * shape[3]
    guard mask.count == pixels, mask.allSatisfy({ $0 == 0 || $0 == 1 }) else {
      throw Self.invalid("The paired-runtime mode-profile mask must be binary")
    }
    let selected = mask.indices.compactMap { mask[$0] == 1 ? UInt32($0) : nil }
    guard !selected.isEmpty else { return [UInt32](repeating: 0, count: 256) }

    let library = try Metal4DSTEMKernels.makePairedRuntimeTANSLibrary(device: queue.device)
    guard let function = library.makeFunction(name: "paired_runtime_tans_detector_mode_histogram")
    else { throw Self.invalid("Paired-runtime mode-histogram kernel is missing") }
    let pipeline = try queue.device.makeComputePipelineState(function: function)
    let selectedBuffer = try Self.upload(
      selected, device: queue.device, label: "paired-runtime mode-profile pixels")
    let histogram = try Self.buffer(
      device: queue.device, bytes: 256 * MemoryLayout<UInt32>.stride,
      options: .storageModeShared, label: "paired-runtime mode histogram")
    memset(histogram.contents(), 0, histogram.length)
    memset(failure.contents(), 0, MemoryLayout<UInt32>.stride)
    guard let command = queue.makeCommandBuffer(),
      let encoder = command.makeComputeCommandEncoder()
    else { throw Self.invalid("Metal could not encode paired-runtime mode profiling") }
    var parameters: [UInt32] = [
      UInt32(pixels),
      UInt32(shape[0] * shape[1] / PairedRuntimeTANSRecordABI.streamScans),
      UInt32(selected.count),
    ]
    encoder.setComputePipelineState(pipeline)
    encoder.setBuffer(modes, offset: 0, index: 0)
    encoder.setBuffer(selectedBuffer, offset: 0, index: 1)
    encoder.setBuffer(histogram, offset: 0, index: 2)
    encoder.setBytes(&parameters, length: parameters.count * 4, index: 3)
    let jobs = Int(parameters[1]) * selected.count
    let width = pipeline.threadExecutionWidth
    encoder.dispatchThreads(
      MTLSize(width: jobs, height: 1, depth: 1),
      threadsPerThreadgroup: MTLSize(
        width: min(pipeline.maxTotalThreadsPerThreadgroup, width * 4),
        height: 1, depth: 1))
    encoder.endEncoding()
    try finish(command, operation: "mode profiling")
    let counts = Array(
      UnsafeBufferPointer(
        start: histogram.contents().assumingMemoryBound(to: UInt32.self), count: 256))
    let expected = UInt64(selected.count) * UInt64(parameters[1])
    guard counts.reduce(UInt64(0), { $0 + UInt64($1) }) == expected else {
      throw Self.invalid("Paired-runtime mode histogram did not count every selected stream")
    }
    return counts
  }

  public func releaseResidentStorage() {
    stateLock.lock()
    defer { stateLock.unlock() }
    payload = nil
    offsets = nil
    modes = nil
    decodingTable = nil
    macroDecodingTable = nil
    polarIndex = nil
    diagnosticScratch = nil
    failure = nil
    diffraction = nil
    detectorProduct = nil
    historyProduct = nil
    historyMask = nil
    historyValid = false
    detectorPartials = nil
    detectorMask.removeAll(keepingCapacity: false)
    metadataLock.lock()
    cachedHistoryHit = false
    cachedHistoryBase = false
    cachedUpdateProfile = [:]
    metadataLock.unlock()
    released = true
    refreshMetadataSnapshot()
  }

  private func requireLive() throws {
    guard !released, payload != nil, offsets != nil, modes != nil,
      decodingTable != nil, failure != nil, diffraction != nil, detectorProduct != nil,
      !historyEnabled || historyProduct != nil
    else { throw Self.invalid("The paired-runtime ANS source was released; load it again") }
  }

  private func finish(_ command: MTLCommandBuffer, operation: String) throws {
    command.commit()
    command.waitUntilCompleted()
    let code = failure.contents().load(as: UInt32.self)
    guard command.status == .completed, command.error == nil, code == 0 else {
      throw Self.invalid(
        "Paired-runtime \(operation) failed with code \(code): "
          + (command.error?.localizedDescription ?? "invalid stream"))
    }
  }

  private func detectorValues() -> [UInt32] {
    Array(
      UnsafeBufferPointer(
        start: detectorProduct.contents().assumingMemoryBound(to: UInt32.self),
        count: shape[0] * shape[1]))
  }

  /// Restore the baseline without reimplementing detector science on the CPU.
  /// The caller holds `stateLock`, and the failed command has finished.
  private func resetDetectorStateAfterFailedUpdate() {
    memset(detectorProduct.contents(), 0, detectorProduct.length)
    detectorMask = [UInt8](repeating: 0, count: validPixels.count)
    polarFieldCount = 0
    polarResidualCount = 0
    refreshMetadataSnapshot()
  }

  /// Publish UI-facing metadata without extending the serialized operation lock.
  /// Callers mutate resident state only while holding `stateLock` or during initialization.
  private func refreshMetadataSnapshot() {
    let indexBytes = polarIndex?.residentBytes ?? 0
    let products = released ? 0
      : failure.length + diffraction.length + detectorProduct.length
        + (historyProduct?.length ?? 0)
    let scratch = released ? 0
      : (detectorPartials?.length ?? 0) + (macroDecodingTable?.length ?? 0)
        + (diagnosticScratch?.byteCount ?? 0)
    let totalBytes = released ? 0
      : loadMetrics.residentBytes + UInt64(products) + UInt64(scratch) + indexBytes
    metadataLock.lock()
    cachedReleased = released
    cachedResidentBytes = totalBytes
    cachedPolarFieldCount = polarFieldCount
    cachedPolarResidualCount = polarResidualCount
    cachedPolarIndexBytes = indexBytes
    cachedPolarIndexBuildMilliseconds = polarIndex?.buildMilliseconds ?? 0
    metadataLock.unlock()
  }

  private static func upload<T>(_ values: [T], device: MTLDevice, label: String) throws
    -> MTLBuffer
  {
    let buffer = values.withUnsafeBytes {
      device.makeBuffer(bytes: $0.baseAddress!, length: $0.count, options: .storageModeShared)
    }
    guard let buffer else { throw invalid("Metal could not allocate \(label)") }
    buffer.label = label
    return buffer
  }

  private static func consolidate(
    provider: PairedRuntimeTANSRecordProvider, library: MTLLibrary, queue: MTLCommandQueue,
    compactOffsetsEnabled: Bool
  ) throws -> (payload: MTLBuffer, offsets: MTLBuffer, modes: MTLBuffer, residentBytes: UInt64) {
    let streamCount = provider.descriptor.streamsPerRecord * provider.records.count
    let recordStreamCount = provider.descriptor.streamsPerRecord
    let payloadBytes = provider.receipt.recordExtents.reduce(0) {
      $0 + $1.terminalPayloadBytes
    }
    guard streamCount > 0, streamCount <= Int(UInt32.max), recordStreamCount > 0,
      payloadBytes <= Int(UInt32.max)
    else {
      throw invalid("One paired-runtime acquisition exceeds the UInt32 payload ABI")
    }
    let pipeline: MTLComputePipelineState
    let compactFailure: MTLBuffer?
    let offsetBytes: Int
    if compactOffsetsEnabled {
      guard streamCount & 31 == 0, recordStreamCount & 31 == 0,
        let rebase = library.makeFunction(
          name: Metal4DSTEMKernels.pairedRuntimeTANSRebaseBlock32OffsetsFunction)
      else {
        throw invalid("Block-32 offset consolidation requires aligned stream counts")
      }
      pipeline = try queue.device.makeComputePipelineState(function: rebase)
      let baseCount = streamCount / 32 + 1
      let (baseBytes, baseOverflow) = baseCount.multipliedReportingOverflow(by: 4)
      let (startsCount, startsCountOverflow) = streamCount.addingReportingOverflow(1)
      let (startsBytes, startsOverflow) = startsCount.multipliedReportingOverflow(by: 2)
      let (packedBytes, packedOverflow) = baseBytes.addingReportingOverflow(startsBytes)
      guard !baseOverflow, !startsCountOverflow, !startsOverflow, !packedOverflow,
        packedBytes <= queue.device.maxBufferLength
      else { throw invalid("Compact paired-runtime offsets exceed the Metal buffer limit") }
      offsetBytes = packedBytes
      compactFailure = try buffer(
        device: queue.device, bytes: 4, options: .storageModeShared,
        label: "paired-runtime compact offset validation")
      memset(compactFailure!.contents(), 0, 4)
    } else {
      guard let rebase = library.makeFunction(
        name: Metal4DSTEMKernels.pairedRuntimeTANSRebaseOffsetsFunction)
      else { throw invalid("Paired-runtime offset consolidation kernel is missing") }
      pipeline = try queue.device.makeComputePipelineState(function: rebase)
      offsetBytes = (streamCount + 1) * 4
      compactFailure = nil
    }
    let payload = try buffer(
      device: queue.device, bytes: max(8, ((payloadBytes + 3) & ~3) + 8),
      options: .storageModePrivate, label: "paired-runtime acquisition payload")
    let offsets = try buffer(
      device: queue.device, bytes: offsetBytes,
      options: .storageModePrivate,
      label: compactOffsetsEnabled
        ? "paired-runtime acquisition compact offsets" : "paired-runtime acquisition offsets")
    let modes = try buffer(
      device: queue.device, bytes: streamCount,
      options: .storageModePrivate, label: "paired-runtime acquisition modes")
    guard let command = queue.makeCommandBuffer() else {
      throw invalid("Metal could not consolidate paired-runtime records")
    }
    var payloadFirst = 0
    for (recordIndex, record) in provider.records.enumerated() {
      let extent = provider.receipt.recordExtents[recordIndex]
      guard let blit = command.makeBlitCommandEncoder() else {
        throw invalid("Metal could not copy paired-runtime records")
      }
      if extent.terminalPayloadBytes > 0 {
        blit.copy(
          from: record.payload, sourceOffset: 0, to: payload,
          destinationOffset: payloadFirst, size: extent.terminalPayloadBytes)
      }
      blit.copy(
        from: record.modes, sourceOffset: 0, to: modes,
        destinationOffset: recordIndex * provider.descriptor.streamsPerRecord,
        size: provider.descriptor.streamsPerRecord)
      blit.endEncoding()
      guard let encoder = command.makeComputeCommandEncoder() else {
        throw invalid("Metal could not rebase paired-runtime record offsets")
      }
      encoder.setComputePipelineState(pipeline)
      encoder.setBuffer(record.offsets, offset: 0, index: 0)
      encoder.setBuffer(offsets, offset: 0, index: 1)
      if compactOffsetsEnabled {
        guard let compactFailure,
          payloadFirst <= Int(UInt32.max),
          extent.terminalPayloadBytes <= Int(UInt32.max)
        else { throw invalid("Compact paired-runtime offset parameters exceed UInt32") }
        var parameters: [UInt32] = [
          UInt32(recordStreamCount), UInt32(recordIndex * recordStreamCount),
          UInt32(payloadFirst), UInt32(streamCount), UInt32(extent.terminalPayloadBytes),
        ]
        encoder.setBuffer(compactFailure, offset: 0, index: 2)
        encoder.setBytes(&parameters, length: parameters.count * 4, index: 3)
      } else {
        var parameters: [UInt32] = [
          UInt32(recordStreamCount), UInt32(recordIndex * recordStreamCount),
          UInt32(payloadFirst),
        ]
        encoder.setBytes(&parameters, length: parameters.count * 4, index: 2)
      }
      encoder.dispatchThreads(
        MTLSize(width: recordStreamCount + 1, height: 1, depth: 1),
        threadsPerThreadgroup: MTLSize(width: 256, height: 1, depth: 1))
      encoder.endEncoding()
      payloadFirst += extent.terminalPayloadBytes
    }
    command.commit()
    command.waitUntilCompleted()
    guard command.status == .completed, command.error == nil else {
      throw invalid(
        "Paired-runtime record consolidation failed: "
          + (command.error?.localizedDescription ?? "unknown Metal failure"))
    }
    if let compactFailure {
      let failureCode = compactFailure.contents().load(as: UInt32.self)
      guard failureCode == 0 else {
        throw invalid("Compact paired-runtime offset validation failed (code \(failureCode))")
      }
    }
    return (
      payload, offsets, modes,
      UInt64(payload.length + offsets.length + modes.length))
  }

  private static func buffer(
    device: MTLDevice, bytes: Int, options: MTLResourceOptions, label: String
  ) throws -> MTLBuffer {
    guard let buffer = device.makeBuffer(length: bytes, options: options) else {
      throw invalid("Metal could not allocate \(label)")
    }
    buffer.label = label
    return buffer
  }

  private static func invalid(_ message: String) -> Metal4DSTEMStreamingIOError {
    .invalidRequest(message)
  }

  private static let trustedTableExpected: Result<[UInt32], PairedRuntimeTANSTableError> = {
    do {
      let tables = try PairedRuntimeTANSTables.build()
      return .success(tables.packedDecoding)
    } catch let error as PairedRuntimeTANSTableError {
      return .failure(error)
    } catch {
      return .failure(.invalidExtent)
    }
  }()

  private static func validateTrustedTable(
    provider: PairedRuntimeTANSRecordProvider, queue: MTLCommandQueue, device: MTLDevice
  ) throws {
    let expected: [UInt32]
    switch trustedTableExpected {
    case .success(let values): expected = values
    case .failure(let error): throw error
    }
    guard provider.decodingTable.length == expected.count * MemoryLayout<UInt32>.stride,
      let staging = device.makeBuffer(
        length: expected.count * MemoryLayout<UInt32>.stride, options: .storageModeShared),
      let command = queue.makeCommandBuffer(), let blit = command.makeBlitCommandEncoder()
    else { throw invalid("Trusted paired-runtime table validation could not allocate readback") }
    blit.copy(
      from: provider.decodingTable, sourceOffset: 0, to: staging, destinationOffset: 0,
      size: provider.decodingTable.length)
    blit.endEncoding()
    command.commit()
    command.waitUntilCompleted()
    guard command.status == .completed, command.error == nil else {
      throw invalid("Trusted paired-runtime table readback failed")
    }
    let actual = Array(UnsafeBufferPointer(
      start: staging.contents().assumingMemoryBound(to: UInt32.self), count: expected.count))
    guard actual == expected else {
      let mismatch = actual.indices.first { actual[$0] != expected[$0] } ?? expected.count
      throw invalid("Trusted paired-runtime table differs from deterministic entry \(mismatch)")
    }
    for (entry, code) in actual.enumerated() {
      let bits = (code >> 12) & 15
      let base = code >> 16
      guard bits <= 10,
        base <= UInt32(PairedRuntimeTANSTables.stateCount) - (UInt32(1) << bits)
      else { throw invalid("Trusted paired-runtime table entry \(entry) exceeds state bounds") }
    }
  }
}

/// Bounded concurrent loader for an exact paired-runtime tilt series.
public enum MetalPairedRuntimeTANSSeriesLoader {
  public static func load(
    sources: [Native4DSTEMIndexedSource], device: MTLDevice,
    maximumConcurrentLoads: Int = 3,
    maximumAdditionalBytesPerLoad: UInt64? = nil
  ) async throws -> [MetalPairedRuntimeTANSResidentSource] {
    guard !sources.isEmpty else { return [] }
    guard maximumConcurrentLoads > 0 else {
      throw Metal4DSTEMStreamingIOError.invalidRequest(
        "Paired-runtime series loading requires at least one concurrent load slot")
    }
    var next = 0
    var completed = 0
    var ordered = [MetalPairedRuntimeTANSResidentSource?](
      repeating: nil, count: sources.count)
    return try await withThrowingTaskGroup(
      of: (Int, MetalPairedRuntimeTANSResidentSource).self
    ) { group in
      func submit(_ index: Int) {
        let source = sources[index]
        group.addTask {
          let resident = try MetalPairedRuntimeTANSResidentSource.load(
            source: source, device: device,
            maximumAdditionalBytes: maximumAdditionalBytesPerLoad)
          return (index, resident)
        }
      }
      while next < min(maximumConcurrentLoads, sources.count) {
        submit(next)
        next += 1
      }
      while let (index, resident) = try await group.next() {
        ordered[index] = resident
        completed += 1
        if next < sources.count {
          submit(next)
          next += 1
        }
      }
      guard completed == sources.count else {
        throw Metal4DSTEMStreamingIOError.invalidRequest(
          "Paired-runtime series loading ended before every acquisition was resident")
      }
      return ordered.compactMap { $0 }
    }
  }
}
